export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyC_OtbRKbd44PVwe-V29tN8GqSNRyibbTc",
    authDomain: "timeline-dcdbe.firebaseapp.com",
    databaseURL: "https://timeline-dcdbe.firebaseio.com",
    projectId: "timeline-dcdbe",
    storageBucket: "timeline-dcdbe.appspot.com",
    messagingSenderId: "994894445499",
    appId: "1:994894445499:web:d6475479f454d93577629e",
    measurementId: "G-DK2QWBCLFY"
};