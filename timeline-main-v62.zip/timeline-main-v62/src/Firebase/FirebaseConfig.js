export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyBYhZ7omvR1pnHLRPNq3vcpSSDqFhuxGMg",
    authDomain: "timeline-939a7.firebaseapp.com",
    databaseURL: "https://timeline-939a7-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "timeline-939a7",
    storageBucket: "timeline-939a7.appspot.com",
    messagingSenderId: "448429542457",
    appId: "1:448429542457:web:4169c43c1734049f6711e8",
    measurementId: "G-SBPX1C6FWD"
};