export const SET_BOOKMARKTITLE = 'SET_BOOKMARKTITLE'

export const setBookmarkTitle = (options) => {
    return {
        type: SET_BOOKMARKTITLE,
        options: options
    }
}