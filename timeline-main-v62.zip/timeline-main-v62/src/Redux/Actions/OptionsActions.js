export const SET_OPTIONS = 'SET_OPTIONS'

export const setOptions = (options) => {
    return {
        type: SET_OPTIONS,
        options: options
    }
}