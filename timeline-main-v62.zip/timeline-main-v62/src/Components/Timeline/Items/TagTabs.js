import React, {useEffect} from 'react';
import './TagTabs.css'
import { makeStyles } from '@material-ui/core/styles';
import LockIcon from '../../../Assets/oneStar.svg'
import "firebase/auth";
import "firebase/database";
import firebase from "firebase/app";
import EditOutlined from '@material-ui/icons/EditOutlined';

const useStyles = makeStyles((theme) => ({
  root: {
      position: 'absolute',
      right: 59,
      height: '100%',
      backgroundColor: 'transparent'
  },
  paper: {
    marginRight: theme.spacing(2),
  },
  tabContainer: {
      backgroundColor: '#fff'
  }
}));
function isNumeric(str) {
  if (typeof str != "string") return false  
  return !isNaN(str) && !isNaN(parseFloat(str))
}
function TagsMenuList(props) {

  const Tags = Array.isArray(props.tags) ? props.tags : []

  
  const {
    id,
    group
  } = props

  const currentUser = firebase.auth().currentUser;
  const eventRef = firebase.database().ref("Timelines/" + currentUser.uid + "/" + group + "/" + id);

  var notes = props.notes || {}

  var alphabeticalOrderKeyMap = {
    'A': {tagArr: []},
    'B': {tagArr: []},
    'C': {tagArr: []},
    'D': {tagArr: []},
    'E': {tagArr: []},
    'F': {tagArr: []},
    'G': {tagArr: []},
    'H': {tagArr: []},
    'I': {tagArr: []},
    'J': {tagArr: []},
    'K': {tagArr: []},
    'L': {tagArr: []},
    'M': {tagArr: []},
    'N': {tagArr: []},
    'O': {tagArr: []},
    'P': {tagArr: []},
    'Q': {tagArr: []},
    'R': {tagArr: []},
    'S': {tagArr: []},
    'T': {tagArr: []},
    'U': {tagArr: []},
    'V': {tagArr: []},
    'W': {tagArr: []},
    'X': {tagArr: []},
    'Z': {tagArr: []},
    '1': {tagArr: []},
  }

  const TagMenuList = [
    { label: 'A', key: 'A'},
    { label: 'B', key: 'B'},
    { label: 'C', key: 'C'},
    { label: 'D', key: 'D'},
    { label: 'E', key: 'E'},
    { label: 'F', key: 'F'},
    { label: 'G', key: 'G'},
    { label: 'H', key: 'H'},
    { label: 'I', key: 'I'},
    { label: 'J', key: 'J'},
    { label: 'K', key: 'K'},
    { label: 'L', key: 'L'},
    { label: 'M', key: 'M'},
    { label: 'N', key: 'N'},
    { label: 'O', key: 'O'},
    { label: 'P', key: 'P'},
    { label: 'Q', key: 'Q'},
    { label: 'R', key: 'R'},
    { label: 'S', key: 'S'},
    { label: 'T', key: 'T'},
    { label: 'U', key: 'U'},
    { label: 'V', key: 'V'},
    { label: 'W', key: 'W'},
    { label: 'X', key: 'X'},
    { label: 'Z', key: 'Z'},
    { label: '1', key: '1'},
  ]
  Tags.forEach(tag => {
    let startingChar = tag ?  tag.toString().trim().charAt(0).toUpperCase()  : ''
    if(alphabeticalOrderKeyMap['1'].tagArr && isNumeric(tag)){
      alphabeticalOrderKeyMap['1'].tagArr.push(tag)
    }
    else if(alphabeticalOrderKeyMap[startingChar] && alphabeticalOrderKeyMap[startingChar].tagArr && alphabeticalOrderKeyMap[startingChar].tagArr.indexOf(tag) == -1){
      alphabeticalOrderKeyMap[startingChar].tagArr.push(tag)
    }
    
  });
  
  const expandTags = (key, panel) => {
    let elemPanel = document.getElementById(key+panel)
    elemPanel.classList.toggle(panel);
  }

  useEffect(function () {
      
  }, [])

  function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  function getRandomLightColor() {
    var letters = 'BCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.floor(Math.random() * letters.length)];
    }
    return color;
}

function NoteComponent(props) {
  const {
    obj
  } = props
  const noteObj = props.noteObj

  var timeoutTitleId;
  var timeoutNoteId;

  const [ title, setTitle ] = React.useState(noteObj.title);
  const [ note, setNote ] = React.useState(noteObj.note);
  const [ locked, setLocked ] = React.useState(noteObj.locked);

  const onTitleChangeHandler = (e) => {
    // Used Debounce the textarea and input change.
    let _title = e.target.value
    setTitle(_title)

    if(notes[obj.key]) notes[obj.key]['title'] =  _title
    else notes[obj.key] = { title: _title }

    clearTimeout(timeoutTitleId);
    timeoutTitleId = setTimeout(function() {
        eventRef.child('notes').child(obj.key).child('title').set(_title)
    }, 1000);
  }
  const onNoteChangeHandler = (e) => {
    // Used Debounce the textarea and input change.
    let _note =  e.target.value
    setNote(_note)
    if(notes[obj.key])  notes[obj.key]['note'] =  _note
    else notes[obj.key] = {note: _note}

    clearTimeout(timeoutNoteId);
    timeoutNoteId = setTimeout(function() {
        eventRef.child('notes').child(obj.key).child('note').set(_note)
    }, 1000);
  }

  const onLockedClickHandler =  async () => {
    setLocked(!locked)
    if(notes[obj.key])  notes[obj.key]['locked'] =  (!locked)
    else notes[obj.key] = { locked: !locked }

    try {
      await eventRef.child('notes').child(obj.key).child('locked').set(!locked)
    } catch (error) {}
  }

  return (
    <div className={locked ? 'notes-item note-locked' : 'notes-item'} id={obj.key+'_notes_panel'} style={{backgroundColor: getRandomLightColor()}}>
      <div style={{
        textAlign: 'left', 
        fontWeight: 700,
        display: 'flex',
        justifyContent: 'space-between'
      }}>
        <input 
          type="text" 
          className="note-inputs" 
          autoFocus 
          value={title}  
          onChange={onTitleChangeHandler}
          style={{width: '75%'}} 
          placeholder="Type title here"
        />
        <span>
          <img src={LockIcon} onClick={onLockedClickHandler} width={25} />
        </span>
        </div>
        <div className="notes-item-container">
          <div style={{
            width: '100%',
            height: 'auto',
            maxHeight: 150,
            zIndex: -2,
            borderTopLeftRadius: 10,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            borderBottomLeftRadius: 10,

          }}>
            <textarea 
              className="note-inputs" 
              type="text" 
              value={note} 
              placeholder="Note"
              onChange={onNoteChangeHandler}
              style={{ width: '100%', padding: '10px 10px' }}
              />
          </div>
      </div>
    </div>
  )
}

  return (
    <div className="tabContainer">
      <ul className="tagTabMenu">
        {
          TagMenuList.map(obj=>{
            let bgColor = getRandomColor()
            let alphabetObj = alphabeticalOrderKeyMap[obj.key]
            let noteObj = notes[obj.key] || {}

            return <li key={obj.key}>
                    <div onClick={()=>expandTags(obj.key, '_tags_panel')} className="menuItem">{obj.label}</div>
                    <div onClick={()=>expandTags(obj.key, '_notes_panel')} className="colorTagItem" style={{backgroundColor: bgColor}}></div>
                    <div className="tag-item" id={obj.key+'_tags_panel'} >
                      <div style={{textAlign: 'right', fontWeight: 700}}>TAGS {obj.label} ({alphabetObj.tagArr.length})</div>
                      <div className="tag-item-container">
                        <div style={{
                          width: 100,
                          height: 'auto',
                          padding: '10px 20px',
                          display:  'flex',
                          flexDirection: 'column',
                          zIndex: -2,
                          borderTopLeftRadius: 10,
                          borderBottomLeftRadius: 10,
                        }}>
                          {
                            alphabetObj.tagArr.map(tag  => <span className="tag-item-tags">{tag}</span>)
                          }
                        </div>
                      </div>
                    </div>
                    <NoteComponent noteObj={noteObj} obj={obj} />
                  
                  </li>
          })
        }
      </ul>
    </div>
  );
}

export default React.memo(TagsMenuList)