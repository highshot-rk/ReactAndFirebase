import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import timeSince from './timeAgo';
import "firebase/auth";
import "firebase/database";
import firebase from "firebase/app";
import Alert from '@material-ui/lab/Alert';
import { useDispatch } from "react-redux";
import { setItemsData } from "../../../Redux/Actions/ItemActions.js";
import { bookmarkReadyToAdd, addEvent } from "../../../Redux/Actions/BookmarksActions.js";
import timeAgoIcon from "../../../Assets/timeAgoButton.svg"
import  verifiedIcon  from "../../../Assets/verifiedIcon.svg"
import shareButton from "../../../Assets/shareButton.svg"
import DownArrow from "../../../Assets/optionsButton_Down.svg"
import BookmarkCircle from "../../../Assets/bookmarkCircle.svg"
import EditModeIcon from "../../../Assets/tlEditIcon.svg"
import EditOnIcon from "../../../Assets/EditIconOn.svg"
import EditOffIcon from "../../../Assets/EditIconoff.svg"
import Microphone from "../../../Assets/tlMicrophone.svg"
import TagTargetIcon from "../../../Assets/tagTargetIcon.svg"

import Collapse from '@material-ui/core/Collapse';
import Gallery from 'react-grid-gallery';
import CountryFlags from 'react-country-flag'
import Rating from "@material-ui/lab/Rating";
import { green } from '@material-ui/core/colors';
import CircularProgress from '@material-ui/core/CircularProgress'
import TabTagsHide from '../../../Assets/tagTabsShow.svg'

import { EditorState, convertToRaw, convertFromHTML, ContentState } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';

import './eventDetailsStyle.css'
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import TagTabs from './TagTabs'
import moment from 'moment';

const getEvents = async (dispatch) => {
  const currentUser = firebase.auth().currentUser;
  await firebase
    .database()
    .ref("Timelines/" + currentUser.uid)
    .once("value", async (snapshot) => {
      let fetched = snapshot.val();
      const events = {};
      if (fetched) {
        Object.keys(fetched).forEach((key) => {
          events[key] = Object.keys(fetched[key]).map((itemKey) => ({
            ...fetched[key][itemKey],
            group: key,
          }));
        });
        dispatch(setItemsData(events));
      }
    });
};
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};

const useStyles = makeStyles((theme) => ({
  root: {
    width: "56vw",
    height: "90vh",
    backgroundColor: "white",
    borderRadius: "10px",
    paddingLeft: 25,
    paddingRight: 25
  },
  heading: {
    height: "auto",
    padding: "20px 10px 10px 10px",
  },
  headingRow1: {
    display: "flex",
    justifyContent: "space-between",
  },
  time: {
    fontSize: "20px",
    color: "red",
    fontFamily: "Quantico",
    fontStyle: "italic",
  },
  title: {
    fontWeight: 600,
    fontSize: "32px",
  },
  body: {
    height: "calc(100% - 160px)",
    overflowY: "scroll",
    display: "flex",
    width: "100%",
    padding: "10px",
  },
  partA: {
    //backgroundColor: "red",
    width: "70%",
    //height: "500px",
  },
  partB: {
    width: "30%",
  },
  video: {
    marginTop: "20px",
    width: "100%",
    display: "flex",
    justifyContent: "center",
  },
  footer: {
    height: "30px",
    display: "flex",
    alignItems: "center",
    display: 'flex',
    justifyContent: 'space-between',
    paddingLeft: "10px",
    paddingRight: "10px",
    fontSize: "1em",
    fontWeight: "bold",
    borderBottomLeftRadius: "10px",
    borderBottomRightRadius: "10px",
    marginTop: '30px',
    position: 'absolute',
    width: '100%',
    bottom: 0,
    right: 0
  },
  buttonSuccess: {
    backgroundColor: green[500],
    '&:hover': {
      backgroundColor: green[700],
    },
  },
  fabProgress: {
    color: green[500],
    position: 'absolute',
    top: 4,
    left: 8,
    zIndex: 1,
  },
  buttonProgress: {
    color: green[500],
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -12,
    marginLeft: -12,
  },
  showTagTabButton: {
    position: 'absolute',
    right: 4,
    top: 4,
    transition: 'display 0.2s ease',
    cursor: 'pointer',
    '&:hover': {
      opacity: 0.9,
    },
  },
  tagTabsContainer: {
    zIndex: -1,
    transition: 'opacity 0.2s ease',
  }
}));

const EventDetails = ({ item, onSave }) => {
  
 
  
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  const [editMode, setEditMode] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const [showTagTabs, setShowTagTabs] = React.useState(false);

  const {
    imgURL,
    videoURL,
    mAudioURL,
    color,
    tagColor,
    id,
    ebPicURL,
    otherImages,
    profileTagURL,
    country,
    group,
    eventPinned,
    type2,
    notes,
    flag
  } = item;

  const [editorState, setEditorState] = React.useState(() =>  {
      if(item.description){
        return EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(item.description)))
      } else {
        return EditorState.createEmpty()
      }
    }
  );

  const [title, setTitle] = React.useState(item.title);
  const [description, setDescription] = React.useState(item.description);
  const [start, setStart] = React.useState(item.start);
  const [starRating, setStarRating] = React.useState(item.starRating);
  const [tags, setTags] = React.useState(item.tags);

  const classes = useStyles();
 
  const [loading, setLoading] = React.useState(false);
  const timer = React.useRef();

  const IMAGES = otherImages.map(img=> {
    return {
          src: img,
          thumbnail: img,
          thumbnailWidth: 100,
          thumbnailHeight: 100
    }
  })
    
  const onEditorStateChange = (editorState) => {
    setEditorState(editorState);
    setDescription(draftToHtml(convertToRaw(editorState.getCurrentContent())))
  };

  const timeAgoHover = () => {
    document.getElementsByClassName('exact-time-ago')[0].style.visibility = 'visible'
  }
  const timeAgoHoverOut = () => {
    document.getElementsByClassName('exact-time-ago')[0].style.visibility = 'hidden'
  }
  const timeZoneHoverOut = () => {
    document.getElementsByClassName('timezone')[0].style.visibility = 'hidden'
  }
  const timeZoneHover = () => {
    document.getElementsByClassName('timezone')[0].style.visibility = 'visible'
  }

  const pintoLCDHandler = event => {
    // TODO: pin event to LCD
  }

  const pinThisEventHandler = async () => {
    const currentUser = firebase.auth().currentUser;
    const eventRef = firebase.database().ref("Timelines/" + currentUser.uid + "/" + group + "/" + id);
    await eventRef.child("eventPinned").set(!eventPinned)
    getEvents(dispatch)
  }

  const handleSelect = () => {
    dispatch(addEvent({ id, title }));
  };
  const handleClickSelect = () => {
    
  };
  const handleUnSelect = () => {
    dispatch(addEvent(null));
    setSelect(false);
  };

  const toggleEditMode = () => {
    setEditMode(!editMode) 
  }

  const editClickHandler = () => {
    if(editMode) {
      updateEventData()
    } else {
      toggleEditMode()
    }
  }
 
  const updateEventData = async ()  => {

    let eventObj = {  starRating }
    eventObj.title = title ? title : ''
    eventObj.description = description ? description: ''
    eventObj.tags = tags ? tags: []
    if(start) eventObj.start_date = start
    
    setLoading(true);
    try {
      const currentUser = firebase.auth().currentUser;
      const eventRef = firebase.database().ref("Timelines/" + currentUser.uid + "/" + group + "/" + id);
      await eventRef.update(eventObj)
    } catch (error) {
      console.log(error)
    }
    setLoading(false);
    setOpen(true)
    setTimeout(()=>{
      setOpen(false)
    }, 1500)
    toggleEditMode()
    if(onSave) onSave()
  }

  return (
    <>
      <div className="exact-time-ago">
        <span>{`Exactly ${timeSince(new Date(start), 0)}`}</span>
      </div>
      <Collapse in={open}>
        <Alert>Event details saved successfully!</Alert>
      </Collapse>
      <div className={classes.root} style={{ position: 'relative' }}>
        {showTagTabs  ? <TagTabs id={id} group={group} tags={tags} notes={notes} editMode/> : null}
        <div className={classes.headingTop}>                   
          {
            [
              editMode 
              ? <img src={EditOnIcon} width={35} onClick={editClickHandler} className="edit-mode-icon" />
              : <img src={EditOffIcon} width={35} onClick={editClickHandler} className="edit-mode-icon" />,
              
              loading && <CircularProgress size={35} className={classes.fabProgress} />
            ]
          }
          
          <img src={TabTagsHide} onClick={()=>{setShowTagTabs(!showTagTabs)}}  width={20} className={classes.showTagTabButton}/>
        </div>
        <div className={classes.heading}>
          <div className={classes.headingRow1}>
            
            <div className={classes.time}>
              
                {
                  editMode 
                  ? <input className="input-date-modal" type="datetime-local" value={moment(start).format('YYYY-MM-DDThh:mm')} onChange={(e)=>{setStart(e.target.value)}}/>
                  : [
                    <span style={{ whiteSpace: 'nowrap',fontFamily:"Arial", fontSize: '1.2em' }}>
                      {moment(start).format('ddd Do MMMM YYYY')}
                    </span>,
                    <span
                        style={{
                          color: "black",
                          marginLeft: "8px",
                          position: 'relative'
                        }}
                        className="timezone-localtime"
                        onMouseLeave={() => timeZoneHoverOut()}
                        onMouseEnter={() => timeZoneHover()}
                      >
                        {moment(start).format('h:mm:ss')}
                        <span
                          className="timezone"
                          style={{ color: 'black', position: 'absolute', top: '-32px', right: '-12px', whiteSpace: 'nowrap', fontSize: 16, borderRadius: 4, padding: '3px 4px' }}
        
                        >{`[GMT +${new Date().toGMTString().valueOf().slice(17, 22)}]`}
                        </span>
                      </span>
                  ]
                  
                  
                }
              
            </div>
            <div className="event-detail-icons" style={{ marginLeft: 2 }}>
              <img onMouseLeave={() => timeAgoHoverOut()} onMouseEnter={() => timeAgoHover()} src={timeAgoIcon}
                style={{
                  width: 25,
                  margin: '0 6px',
                  cursor: 'pointer'
                }}
                alt="rightHeader"
              />
               {/* <ReactTimeAgo date={item.start} />  */}

              <span onMouseLeave={() => timeAgoHoverOut()}
                onMouseEnter={() => timeAgoHover()}
                style={{ fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>
                {moment(start).startOf('hours').fromNow()}
              </span>
              <img src={shareButton}
                style={{
                  width: 25,
                  margin: '0 6px'
                }}
                alt="rightHeader"
              />
              <CountryFlags
                countryCode={flag ? flag.trim().toUpperCase() : 'US'}
                svg
                style={{
                    width: 50,
                    height: 20,
                    margin: 0,
                    padding: 0
                }}
                title={flag}
            />
              <img src={verifiedIcon}
                style={{
                  width: 25,
                  margin: '0 6px'
                }}
                alt="rightHeader"
              />
            </div>
            <div>
              <Rating
                className={classes.eventRating}
                value={starRating * 2}
                max={10} 
                onChange={(e)=>{setStarRating(Number(e.target.value/2))}}
                size={"medium"} 
                name={''}
                readOnly={!editMode}
              />
            </div>
          </div>
          
        </div>
        
        <div className={classes.body} style={{ position: 'relative' }}>
        
          <div className={classes.partA} style={{paddingRight: 5}}>
          {
            editMode
            ? [
              <div className={classes.title}>
                <input  onChange={(e)=>{setTitle(e.target.value)}} className="title-input" value={title} />
              </div>,
              <Editor 
                editorState={editorState} 
                wrapperClassName="demo-wrapper"
                editorClassName="demo-editor"
                onEditorStateChange={onEditorStateChange} 
              />
              
            ]
            : <>
              <div className={classes.title}>
                {title}
              </div>
              <div dangerouslySetInnerHTML={{__html: description}}></div>
            </>
          }
          
            
            {videoURL &&
              videoURL.map((e, i) => (
                <div key={i} className={classes.video}>
                  {
                    type2 == 'eb15'
                    ? <video 
                        width="90%"
                        height="80%" src={videoURL} controls>
                      </video>
                    : <iframe
                      width="560"
                      height="315"
                      src={e}
                      frameborder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowfullscreen
                    ></iframe>
                  }
                  
                </div>
              ))}
          </div>
          <div className={classes.partB} style={{marginBottom: 8}}>
              <Gallery images={IMAGES}/>
          </div>
        </div>
        <div className={classes.footer} style={{ backgroundColor: (color  ? color  : color) }}>
          <div>
            <img width={20} height={20} src={DownArrow} style={{opacity: 1}} onClick={pinThisEventHandler}/>
            <img width={20} height={20} src={BookmarkCircle} onClick={handleSelect}/>
            
            <span style={{color: generateContrastColor((color  ? color  : color))}}>&nbsp; {title}</span>
            <span className="pintoLCD" onClick={pintoLCDHandler}></span>
          </div>
          <div>
            <span style={{color: generateContrastColor((color  ? color  : color))}}>TAGS:
              {
                editMode 
                ? <input 
                    className="tag-input" 
                    type="text" 
                    value={(tags ? tags.join(',') : '')} 
                    onChange={(e)=>{setTags(e.target.value.split(','))}}
                    style={{color: generateContrastColor((color  ? color  : color))}}
                    />
                : (tags ? tags.join(',') : '')
              }
            </span>
            <img width={20} height={20} src={Microphone} onClick={handleClickSelect} style={{marginLeft: 8, cursor: 'pointer'}}/>
            <img width={20} height={20} src={TagTargetIcon} onClick={handleClickSelect} style={{marginLeft: 8,  cursor: 'pointer'}}/>
            {
              [
                editMode 
                ? <img src={EditOnIcon} width={25} onClick={editClickHandler} style={{marginLeft: 8, cursor: 'pointer'}}/>
                : <img src={EditOffIcon} width={25} onClick={editClickHandler} style={{marginLeft: 8, cursor: 'pointer'}}/>
              ]
            }
          </div>
        </div>
      </div>
    </>
  );
};

export default EventDetails;
