import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import '../eventDetailsStyle.css'
import { useDispatch } from "react-redux";
import Rating from "@material-ui/lab/Rating";
import FemaleIcon from '../../../../Assets/femaleIcon.svg'  
import MaleIcon from '../../../../Assets/maleIcon.svg'  
import DownArrow from "../../../../Assets/optionsButton_Down.svg"
import BookmarkCircle from "../../../../Assets/bookmarkCircle.svg"
import  verifiedIcon  from "../../../../Assets/verifiedIcon.svg"
import shareButton from "../../../../Assets/shareButton.svg"
import moment from 'moment'
import CountryFlags from 'react-country-flag'
import { bookmarkReadyToAdd, addEvent } from "../../../../Redux/Actions/BookmarksActions.js";
import { ArrowUpwardRounded, ArrowUpwardSharp, ArrowUpwardTwoTone, ArrowUpward } from '@material-ui/icons';
import {
  FacebookIcon,
  TwitterIcon,
  TelegramIcon,
  WhatsappIcon,
  LinkedinIcon,
  PinterestIcon,
  RedditIcon,
  TumblrIcon,
  ViberIcon,
  EmailIcon,
  MailruIcon
} from "react-share";
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  root: {
    width: "56vw",
    height: "70vh",
    backgroundColor: "white",
    borderRadius: "10px",
  },
  heading: {
    height: "100px",
    padding: "20px 10px 0px 10px",
  },
  headingRow1: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: 'baseline'
  },
  profileName: {
    fontFamily: "Quantico",
    paddingTop: '10px',
    fontSize: '1.2em'
  },
  title: {
    fontWeight: 600,
    fontSize: "32px",
  },
  body: {
    height: "calc(100% - 160px)",
    overflowY: "scroll",
    display: "flex",
    width: "100%",
    padding: "10px",
    paddingTop: 0
  },
  partA: {
    //backgroundColor: "red",
    width: "60%",
    //height: "500px",
  },
  video: {
    marginTop: "20px",
    width: "100%",
    display: "flex",
    justifyContent: "center",
  },
  partB: {
    //backgroundColor: "blue",
    width: "40%",
    //height: "1500px",
  },
  footer: {
    height: "30px",
    display: "flex",
    alignItems: "center",
    display: 'flex',
    justifyContent: 'space-between',
    paddingLeft: "10px",
    paddingRight: "10px",
    fontSize: "1em",
    fontWeight: "bold",
    borderBottomLeftRadius: "10px",
    borderBottomRightRadius: "10px",
    marginTop: '30px'
  },
  bottomLine: {
    marginTop: '0.5rem',
    marginBottom: '1rem',
    borderTop: '4px solid #00bcf7',
    borderRadius: 1
  },
  time: {
    color: "red",
    fontFamily: "Quantico",
    fontStyle: "italic",
  },
  labels: {
    fontSize: '1em',
    fontWeight: '700',
    color: "#222",
    paddingRight: '4px',
    textTransform: 'uppercase',
    fontStyle: 'normal',
    fontFamily: "Quantico",
  },
  labelValue: {
    fontFamily: "Quantico",
    fontSize: '1em',
    fontWeight: '400',
  },
  row: {
    display: 'flex', 
    paddingRight: '1.5rem',
    alignItems: 'center'
  },
  column: {
    borderRight: '4px solid #00bcf7', 
    borderRadius: 1,
    paddingRight: '4px'
  },
  socialContainer: {
    display: 'flex',
    flexDirection: 'row',
    paddingRight: 15,
    transaction: 'width 0.2s ease'
  },
  socialIcon: {
    marginRight: 10,
    cursor: 'pointer',
  },
  eventDetailIcons: {
    width: 25,
    margin: '0 6px 0 0'
  }
}));

const ProfileModal = ({ item }) => {
  const classes = useStyles();

  const [toggleSocialBtn, setToggleSocialBtn] = React.useState(false)
  var {
    start,
    title,
    description,
    imgURL,
    videoURL,
    mAudioURL,
    tags=['Male', 'Model', 'Miss world', '2021'],
    starRating,
    color,
    tagColor,
    id,
    ebPicURL,
    otherImages,
    profileTagURL,
    username,
    
    firstName,
    motherName,
    lastName,
    formerName,
    alias,
    birthDate,
    biography,
    age,
    sex,
    location,
    ethnicity,
    country,
    school,
    college,
    university,
    qualification,
    relations,
    associates,
    connections,
    themesTriggers,
    profileGroup,
    qrt,
    googleMapUrls,
    locations,
    link,
    flag,
  } = item;
  var _sex = (sex == 'f' || sex == 'female' || sex == 'Female') ? 'female' : 'male'

  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);

  const handleSelect = () => {
    dispatch(addEvent({ id, title }));
  };
  const handleUnSelect = () => {
    dispatch(addEvent(null));
    setSelect(false);
  };

  const toggleSocialIcons = () => {
    setToggleSocialBtn(!toggleSocialBtn)
  }
  const timeAgoHover = () => {
    document.getElementsByClassName('exact-time-ago')[0].style.visibility = 'visible'
  }
  const timeAgoHoverOut = () => {
    document.getElementsByClassName('exact-time-ago')[0].style.visibility = 'hidden'
  }
  const timeZoneHoverOut = () => {
    document.getElementsByClassName('timezone')[0].style.visibility = 'hidden'
  }
  const timeZoneHover = () => {
    document.getElementsByClassName('timezone')[0].style.visibility = 'visible'
  }

  const pintoLCDHandler = event => {
    // TODO: pin event to LCD
  }

  const getProfileName = (firstName, motherName, formerName) => {
    let name = ''
    if(firstName) name = firstName
    if(motherName) name = name + ' ' + motherName
    if(formerName) name = name + ' ' + formerName
    return name
  }

  React.useEffect(()=>{
    biography = 'Mia Pochellow was born in'

  },[item])
  return (
    <>
      <div className={classes.root} style={{ position: 'relative' }}>

        <div className={classes.heading}>
          <div className={classes.headingRow1}>
            <div className={classes.profileName}>
                <span className={classes.labels}>Name:</span>
              <span className={classes.labelValue}>
                {getProfileName(firstName, motherName, formerName)}
              </span>
              <hr className={classes.bottomLine}/>
            </div>
            <div className="event-detail-icons">
              
              <CountryFlags
                countryCode={flag ? flag.trim().toUpperCase() : 'US'}
                svg
                style={{
                  width: 50,
                  height: 20,
                  margin: 0,
                  padding: 0
                }}
                title={country}
            />
              
              <img src={verifiedIcon}
                className={classes.eventDetailIcons}
                alt="rightHeader"
              />
              <img onClick={toggleSocialIcons} src={shareButton}
                className={classes.eventDetailIcons}
                alt="rightHeader"
              />
            </div>
            <div className={classes.socialContainer}>

            {
              toggleSocialBtn 
              ? <div>

                  <TwitterIcon className={classes.socialIcon} size={22} round={true} />
                  <PinterestIcon className={classes.socialIcon} size={22} round={true} />
                  <FacebookIcon className={classes.socialIcon} size={22} round={true} />
                  <LinkedinIcon className={classes.socialIcon} size={22} round={true} />
                  <TelegramIcon className={classes.socialIcon} size={22} round={true} />
                  <WhatsappIcon className={classes.socialIcon} size={22} round={true} />
                  <TumblrIcon className={classes.socialIcon} size={22} round={true} />
                  <MailruIcon className={classes.socialIcon} size={22} round={true} />
                  <RedditIcon className={classes.socialIcon} size={22} round={true} />
                  <ViberIcon className={classes.socialIcon} size={22} round={true} />
                  <EmailIcon className={classes.socialIcon} size={22} round={true} />
                </div>
              : <div>
                    <Rating
                        className={classes.eventRating}
                        value={starRating * 2}
                        readOnly
                        max={10}
                        size={"large"} 
                        readOnly
                      />
                </div> 
            }
            
            </div>
          </div>
          
        </div>
        
        <div className={classes.body}>
          <div className={classes.partA} style={{paddingRight: 15}}>
          <div>
            <div className={classes.time}>
              <span className={classes.labels}>BIRTHDATE:</span>
                <span className={classes.labelValue} style={{paddingLeft: 5}}>
                  {moment(birthDate).format('MMMM Do YYYY')}
                </span>
                <span style={{color: 'black', fontWeight: 'bold'}}>&nbsp;&nbsp;-&nbsp;&nbsp;</span>
                <span
                  className={classes.labelValue}
                  style={{
                    color: "black",
                    position: 'relative'
                  }}
                  className="timezone-localtime"
                  onMouseLeave={() => timeZoneHoverOut()}
                  onMouseEnter={() => timeZoneHover()}
                >
                  {moment(birthDate).format('h:mm:ss')}
                  <span
                    className="timezone"
                    style={{ color: 'black', position: 'absolute', top: '-32px', right: '-12px', whiteSpace: 'nowrap', fontSize: 16, borderRadius: 4, padding: '3px 4px' }}

                  >{`[GMT +${new Date().toGMTString().valueOf().slice(17, 22)}]`}
                  </span>
                </span>
              </div>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>BIOGRAPHY</span>
            <p style={{paddingTop: 10, fontSize: 15}}>{biography}</p>
            <hr className={classes.bottomLine}/>
          </div>

          <div>
            <span className={classes.labels}>First Name: &nbsp;&nbsp;</span>
            <span className={classes.labelValue}>{firstName}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Middle Name: &nbsp;&nbsp;</span>
            <span className={classes.labelValue}>{motherName} {formerName}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Last Name: &nbsp;&nbsp;</span>
            <span className={classes.labelValue}>{lastName}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>BIRTHDATE: &nbsp;&nbsp;</span>
            <span className={classes.labelValue}>{birthDate}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <div className={classes.row}>
              <div className={classes.column}>
                <span className={classes.labels}>Age:</span>
                <span className={classes.labelValue}>{age}</span>
              </div>
              <div className={classes.column} style={{paddingLeft: '1rem'}}>
                <span className={classes.labels}>Sex:</span>
                <span className={classes.labelValue}>{(_sex == 'female') ? 'F': 'M'}&nbsp;&nbsp;</span>
                {
                  (_sex == 'female') ? <img width={20} height={20} src={FemaleIcon}/> : <img width={20} height={20} src={MaleIcon}/>
                }
              </div>
              <div className={classes.column} style={{paddingLeft: '1rem'}}>
                <span className={classes.labels}>Location:</span>
                <span className={classes.labelValue}>{location}</span>
                <CountryFlags
                  countryCode={flag ? flag.trim().toUpperCase() : 'US'}
                  svg
                  style={{
                      width: 40,
                      height: 15,
                  }}
                  title={flag}
              />
              </div>
            </div>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Ethnicity: </span>
            <span className={classes.labelValue}>{ethnicity}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Country: </span>
            <span className={classes.labelValue}>{country}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>School: </span>
            <span className={classes.labelValue}>{school}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>College: </span>
            <span className={classes.labelValue}>{college}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>University: </span>
            <span className={classes.labelValue}>{university}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Qualification: </span>
            <span className={classes.labelValue}>{qualification}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Relation: </span>
            <span className={classes.labelValue}>{relations}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>associate: </span>
            <span className={classes.labelValue}>{associates}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Connection: </span>
            <span className={classes.labelValue}>{connections}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>Themes: </span>
            <span className={classes.labelValue}>{themesTriggers}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>group: </span>
            <span className={classes.labelValue}>{profileGroup}</span>
            <hr className={classes.bottomLine}/>
          </div>
          <div>
            <span className={classes.labels}>QRT: </span>
            <span className={classes.labelValue}>{qrt}</span>
            <hr className={classes.bottomLine}/>
          </div>
          {
            googleMapUrls && googleMapUrls.map((e, i)=>{
              return <div key={'d'+i}>
                <span className={classes.labels}>Location {i+1}: </span>
                <iframe width='90%' height='250' frameborder='0'  
                  scrolling='no' marginheight='0' marginwidth='0'    
                  src='https://maps.google.com/maps?&amp;q="+   
                  encodeURIComponent( addr ) +  
                  "&amp;output=embed'></iframe>
                  <hr className={classes.bottomLine}/>
              </div>
              
            })
          }
          </div>
          <div className={classes.partB} style={{marginBottom: 8}}>
            
            {profileTagURL &&
              profileTagURL.map((e, i) => (
                <img
                  src={e}
                  alt={`image${i}`}
                  style={{ width: "100%", marginBottom: "5px" }}
                />
              ))}
              {otherImages &&
              otherImages.map((e, i) => (
                <img
                  src={e}
                  alt={`image${i}`}
                  style={{ width: "100%", marginBottom: "5px" }}
                />
              ))}
          </div>
        </div>
        <div className={classes.footer} style={{ backgroundColor: (color  ? color  : color) }}>
          <div>
            <img width={25} height={25} src={DownArrow}/>
            <img width={30} height={30} src={BookmarkCircle} onClick={handleSelect}/>
            <span style={{color: generateContrastColor((color  ? color  : color))}}>&nbsp; {title}</span>
            <span className="pintoLCD" onClick={pintoLCDHandler}></span>
          </div>
          <div>
            <span style={{color: generateContrastColor((color  ? color  : color))}}>TAGS: {tags ? tags.join(', ') : null}</span>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfileModal;
