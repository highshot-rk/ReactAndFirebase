import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Rating from "@material-ui/lab/Rating";
import timeSince from '../timeAgo';
import { useDispatch } from "react-redux";
import '../eventDetailsStyle.css'
import { bookmarkReadyToAdd, addEvent } from "../../../../Redux/Actions/BookmarksActions.js";
import CountryFlags from 'react-country-flag'
import  verifiedIcon  from "../../../../Assets/verifiedIcon.svg"
import shareButton from "../../../../Assets/shareButton.svg"
import timeAgoIcon from "../../../../Assets/timeAgoButton.svg"
import DownArrow from "../../../../Assets/optionsButton_Down.svg"
import BookmarkCircle from "../../../../Assets/bookmarkCircle.svg"
import {Line} from "react-chartjs-2"
import firebase from "firebase/app";
import "firebase/auth";
import "firebase/database";
import moment from 'moment'
import { setItemsData } from "../../../../Redux/Actions/ItemActions.js";

const getEvents = async (dispatch) => {
  const currentUser = firebase.auth().currentUser;
  await firebase
    .database()
    .ref("Timelines/" + currentUser.uid)
    .once("value", async (snapshot) => {
      let fetched = snapshot.val();
      const events = {};
      if (fetched) {
        Object.keys(fetched).forEach((key) => {
          events[key] = Object.keys(fetched[key]).map((itemKey) => ({
            ...fetched[key][itemKey],
            group: key,
          }));
        });
        dispatch(setItemsData(events));
      }
    });
};

const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  root: {
    width: "56vw",
    height: "70vh",
    backgroundColor: "white",
    borderRadius: "10px",
  },
  heading: {
    height: "100px",
    padding: "20px",
  },
  headingRow1: {
    display: "flex",
    justifyContent: "space-between",
  },
  time: {
    fontSize: "20px",
    color: "red",
    fontFamily: "Quantico",
    fontStyle: "italic",
  },
  title: {
    fontWeight: 600,
    fontSize: "32px",
  },
  body: {
    height: "calc(100% - 160px)",
    overflowY: "scroll",
    width: "100%",
    padding: '20px',
    paddingTop: 10
  },
  partA: {
    //backgroundColor: "red",
    width: "100%",
    //height: "500px",
  },
  video: {
    marginTop: "20px",
    width: "100%",
    display: "flex",
    justifyContent: "center",
  },
  partB: {
    //backgroundColor: "blue",
    width: "100%",
    //height: "1500px",
  },
  footer: {
    height: "30px",
    display: "flex",
    alignItems: "center",
    display: 'flex',
    justifyContent: 'space-between',
    paddingLeft: "10px",
    paddingRight: "10px",
    fontSize: "1em",
    fontWeight: "bold",
    borderBottomLeftRadius: "10px",
    borderBottomRightRadius: "10px",
    marginTop: '30px'
  },
}));

const EventDetails = ({ item }) => {
  let longTimeAgo = timeSince(item.start, 0)
  const classes = useStyles();
  const [graphData, setGraphData] = React.useState([])
  const {
    start,
    title,
    description,
    imgURL,
    videoURL,
    mAudioURL,
    tags,
    starRating,
    color,
    tagColor,
    id,
    ebPicURL,
    otherImages,
    profileTagURL,
    country,
    group,
    eventPinned,
    flag
  } = item;

  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);

  const handleSelect = () => {
    dispatch(addEvent({ id, title }));
  };
  const handleUnSelect = () => {
    dispatch(addEvent(null));
    setSelect(false);
  };

  const timeAgoHover = () => {
    document.getElementsByClassName('exact-time-ago')[0].style.visibility = 'visible'
  }
  const timeAgoHoverOut = () => {
    document.getElementsByClassName('exact-time-ago')[0].style.visibility = 'hidden'
  }
  const timeZoneHoverOut = () => {
    document.getElementsByClassName('timezone')[0].style.visibility = 'hidden'
  }
  const timeZoneHover = () => {
    document.getElementsByClassName('timezone')[0].style.visibility = 'visible'
  }

  const pintoLCDHandler = event => {
    // TODO: pin event to LCD
  }

  const rawChartData = {
    stockFullName: "SW Limited.",
    stockShortName: "ASX:SFW",
    price: {
      current: 2.32,
      open: 2.23,
      low: 2.215,
      high: 2.325,
      cap: 93765011,
      ratio: 20.1,
      dividend: 1.67,
    },
    chartData: {
      labels: [
        "10:00",
        "",
        "",
        "",
        "12:00",
        "",
        "",
        "",
        "2:00",
        "",
        "",
        "",
        "4:00",
      ],
      data: [
        2.23,
        2.215,
        2.22,
        2.25,
        2.245,
        2.27,
        2.28,
        2.29,
        2.3,
        2.29,
        2.325,
        2.325,
        2.32,
      ],
    },
  };

  const buildData = ({chartData}) => ({
    labels: chartData.labels,
    datasets: [
        {
            label: "",
            backgroundColor: "rgba(255, 255, 255, 0.1)",
            borderColor: "#222",
            pointBackgroundColor: "#222",
            data: chartData.data,
        },
    ],
});

const options = {
  legend: {
      display: false,
  },
  scales: {
      yAxes: [
          {
              ticks: {
                  fontColor: "rgba(255, 255, 255, 1)",
              },
              gridLines: {
                  display: false,
              },
          },
      ],
      xAxes: [
          {
              ticks: {
                  fontColor: "rgba(255, 255, 255, 1)",
              },
              gridLines: {
                  color: "rgba(255, 255, 255, .2)",
                  borderDash: [5, 5],
                  zeroLineColor: "rgba(255, 255, 255, .2)",
                  zeroLineBorderDash: [5, 5],
              },
          },
      ],
  },
  layout: {
      padding: {
          right: 10,
      },
  },
};

const pinThisEventHandler = () => {
  const currentUser = firebase.auth().currentUser;
  const eventRef = firebase.database().ref("Timelines/" + currentUser.uid + "/" + group + "/" + id);
  eventRef.child("eventPinned").set(!eventPinned)
  getEvents(dispatch)
};

  const initChartData = () => {
    const data = buildData(rawChartData);
    setGraphData(data)
  }

  React.useEffect(function(){
    initChartData()
  }, [])


  return (
    <>
      <div className="exact-time-ago">
        <span>{`Exactly ${longTimeAgo}`}</span>
      </div>
      <div className={classes.root} style={{ position: 'relative' }}>

        <div className={classes.heading}>
          <div className={classes.headingRow1}>
            <div className={classes.time}>
              <span style={{ whiteSpace: 'nowrap',fontFamily:"Arial" }}>
              {moment(start).format('MMMM Do YYYY')}
              </span>

              <span
                style={{
                  color: "black",
                  marginLeft: "8px",
                  position: 'relative'
                }}
                className="timezone-localtime"
                onMouseLeave={() => timeZoneHoverOut()}
                onMouseEnter={() => timeZoneHover()}
              >
                {moment(start).format('h:mm:ss')}
                <span
                  className="timezone"
                  style={{ color: 'black', position: 'absolute', top: '-32px', right: '-12px', whiteSpace: 'nowrap', fontSize: 16, borderRadius: 4, padding: '3px 4px' }}

                >{`[GMT +${new Date().toGMTString().valueOf().slice(17, 22)}]`}
                </span>
              </span>
            </div>
            <div className="event-detail-icons" style={{ marginLeft: 2 }}>
              <img onMouseLeave={() => timeAgoHoverOut()} onMouseEnter={() => timeAgoHover()} src={timeAgoIcon}
                style={{
                  width: 25,
                  margin: '0 6px',
                  cursor: 'pointer'
                }}
                alt="rightHeader"
              />
               {/* <ReactTimeAgo date={item.start} />  */}

              <span onMouseLeave={() => timeAgoHoverOut()}
                onMouseEnter={() => timeAgoHover()}
                style={{ fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>
                {timeSince(item.start, 1)}
              </span>
              <img src={shareButton}
                style={{
                  width: 25,
                  margin: '0 6px'
                }}
                alt="rightHeader"
              />
              <CountryFlags
                countryCode={flag ? flag.trim().toUpperCase() : 'US'}
                svg
                style={{
                  width: 50,
                  height: 20,
                  margin: 0,
                  padding: 0
                }}
                title={flag}
            />
              <img src={verifiedIcon}
                style={{
                  width: 25,
                  margin: '0 6px'
                }}
                alt="rightHeader"
              />
            </div>
            <div>
              <Rating
                className={classes.eventRating}
                value={starRating * 2}
                readOnly
                max={10} 
                size={"medium"} 
                readOnly
              />
            </div>
          </div>
          <div className={classes.title}>{title}</div>
        </div>
        
        <div className={classes.body}>
          <div className={classes.partA} style={{paddingRight: 5}}>
            {description}
          </div>

          <div className={classes.partB} style={{marginBottom: 8}}>
            <div id="graphCanvas">
              <Line data={graphData} options={options} />
            </div>
          </div>
        </div>
        <div className={classes.footer} style={{ backgroundColor: (color  ? color  : color) }}>
          <div>
            <img width={25} height={25} src={DownArrow} onClick={pinThisEventHandler}/>
            <img width={30} height={30} src={BookmarkCircle} onClick={handleSelect}/>
            <span style={{color: generateContrastColor((color  ? color  : color))}}>&nbsp; {title}</span>
          </div>
          <div>
            <span style={{color: generateContrastColor((color  ? color  : color))}}>TAGS: {tags ? tags.join(', ') : null}</span>
          </div>
        </div>
      </div>
    </>
  );
};

export default EventDetails;
