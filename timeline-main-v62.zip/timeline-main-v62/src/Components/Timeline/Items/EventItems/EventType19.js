import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import { bookmarkReadyToAdd } from "../../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "../EventDetails.js";
import CountryFlags from 'react-country-flag'
import shapeStyle from "../shapeStyles"
import moment from "moment"

import EventType13 from '../EventItems/EventType13'
import EventVideoPlayer from '../EventItems/EventVideoPlayer'
import EventAudioPlayer from '../EventItems/EventAudioPlayer'

//const EventItem=(item)=>({
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row",
    position: 'relative'
  },
  
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventImgContainer: {
    width: 363,
    height: 400,
    marginRight: 35,
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'flex-end'
  },
  eventImg: {
    objectFit: "cover",
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
  },
  parentImg: {
    width: 70,
    height: 110,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "3px solid yellow",
    borderRadius: 8, 
    marginTop: -15,
    marginRight: 25
  },
  eventDetails: {
    filter: "drop-shadow(3px 5px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    height: 135,
    width: 400,
    padding: 5,
    borderRadius: 2,
    backgroundColor: "white",
    background: 'linear-gradient(to right, #BF953F, #FCF6BA, #B38728, #FBF5B7, #AA771C)',
    clipPath: "polygon(91% 0, 100% 26%, 100% 75%, 92% 100%, 0 100%, 0 0)"
  },
  
  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 0,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventPictureVLine: {
    position: "absolute",
    height: 50,
    zIndex: -1,
    display: 'block',
    backgroundColor: '#BF953F',
    bottom: 0,
    left: 30,
    width: 1, 
  },
  eventPictureLine: {
    position: "absolute",
    height: 1,
    display: 'block',
    backgroundColor: '#BF953F',
    top: 20,
    width: 100, 
    left: -26,
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventRating: {
    position: "absolute",
    left: "200px",
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
  },
  eventDate: {
    color: "red",
    fontWeight: "bold",
  },
  eventTime: {
    color: "black",
    fontFamily: "Quantico",
    marginLeft: "5px",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily:"Arial"
  },
  eventDescription: {
    lineHeight: "16px",
    height: "48px",
    width: '92%',
    fontSize: "14px",
    paddingRight: "2px",
    overflow: "hidden",
    fontFamily:"Lucida Fax",
    position: 'relative',
    display: 'inline-block',
    wordWrap: 'break-word',
    maxHeight: '3.4em', /* (Number of lines you want visible) * (line-height) */
    textAlign:'justify',
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 0,
    height: "auto",
    width: "296px",
    paddingTop: '10px',
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
  parentImgTag: {
    padding: '0px 8px',
    position: 'absolute',
    top: -55,
    backgroundColor: '#000',
    color: '#fff',
    border: '3px solid #BF953F',
    borderRadius: 4
  },
  parentImgBottomTag: {
    height: 70,
    width: 70,
    position: 'absolute',
    bottom: -50,
    backgroundColor: '#0c3467',
    color: '#fff',
    borderRadius: 4,
    left: 1,
  }
}));

const EventItem = (props) => {
  const bodyBgColor = props.bodyBgColor ? props.bodyBgColor : 'linear-gradient(to right, #BF953F, #FCF6BA, #B38728, #FBF5B7, #AA771C)'
  const {
    start,
    title,
    description,
    imgURL,
    videoURL,
    audioURL,
    tags,
    starRating,
    color,
    tagColor,
    id,
    type2,
    eventType,
    groupImg,
    profileTagURL,
    country,
    flag
  } = props.item;

  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  
  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };

  return (
    <div>
      <div className={classes.root}>
      <div  className={classes.eventImgContainer}>
        <img className={classes.eventImg} alt="event picture" src={imgURL} />
      </div>
        <div className={classes.eventRow}>
          <div className={classes.parentImgTag}>
            MUSIC
          </div>
          <div className={classes.parentImgBottomTag}>
            <img width="100%" height="100%" src={imgURL}/>
          </div>
          <img className={classes.parentImg}
            style={{ borderColor: color}}
            alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
            <div className={classes.eventPictureVLine}>
            </div>
            <div className={classes.eventPictureVLine} style={{left: 50}}>
            </div>
            <div className={classes.eventPictureVLine} style={{left: 65}}>
            </div>
        <div className={classes.eventItem} onClick={handleSelect}>

            <div className={classes.eventPictureLine}>
            </div>
            <div className={classes.eventPictureLine} style={{top: 50}}>
            </div>
            <div className={classes.eventPictureLine} style={{top: 80}}>
            </div>
       
          <div className={classes.eventDetails}>

            <div className={classes.itemEvent} style={{background: bodyBgColor}}>
            
              <div className={classes.leftLine}>
              </div>
              <div className={classes.eventText}>
                <Rating
                  className={classes.eventRating}
                  value={starRating / 2}
                  precision={0.5}
                  size={'small'}
                  readOnly
                />
                <div className={classes.eventDate}>
                    <span style={{fontFamily:"Arial"}}>
                    {moment(start).format('DD MMM YYYY')}
                      </span>
                    <span className={classes.eventTime}>
                      {moment(start).format('HH:mm:ss')}
                    </span>
                  </div>
                <div className={classes.eventTitle}>{title}</div>
                <div className={classes.eventDescription} dangerouslySetInnerHTML={{__html: description}}></div>
              </div>
            </div>
          </div>

          <div
            className={classes.eventTags}
            style={{
              backgroundColor: (tagColor  ? tagColor  : color),
            }}
          >
            <div
              className={classes.tagText}
              style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
            >
              {tags.join(", ")}
            </div>
          </div>
        </div>

        </div>
      </div>
      <Dialog
        open={select}
        onClose={handleUnSelect}
        aria-labelledby="item selected"
        aria-describedby="select an even to view it's details"
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflowY: "scroll",
          
        }}
        PaperProps={{
          style: {
            borderRadius: "10px",
            overflow:"visible",
            maxWidth: "initial"
          },
        }}
        fullWidth={true}
        maxWidth={"lg"}
      >
        <EventDetails onSave={props.onSaveEditModal} item={props.item} />
      </Dialog>
    </div>
  );
  
};
export default EventItem;
