import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import { bookmarkReadyToAdd } from "../../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "../EventDetails.js";
import ProfileEvent from "../eventModals/profileModal";
import GraphModal from "../eventModals/graphModal";
import CountryFlags from 'react-country-flag'
import shapeStyle from "../shapeStyles"
import HoverVideoPlayer from 'react-hover-video-player';
import YoutubeLogo from '../../../../Assets/youtube.png'
import moment from 'moment' 
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row"
  },
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventImg: {
    width: 100,
    height: 120,
    marginRight: 27,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
  },
  parentImg: {
    width: 70,
    height: 70,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "3px solid yellow",
    borderRight: 'none',
    borderTopLeftRadius: 15,
    borderBottomLeftRadius: 15,
    marginTop: 56,
  },
  eventDetails: {
    filter: "drop-shadow(5px 8px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    padding: 10,
    border: "1px solid black",
    borderRadius: 8,
    backgroundColor: "white",
  },
  itemHeader: {
    display: 'flex',
    flexDirection: 'row',
    paddingTop: 10,
    paddingBottom: 10,
    justifyContent: 'space-between'
  },
  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 5,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventPictureLine: {
    position: "absolute",
    height: 0,
    display: 'none',
    backgroundColor: 'black',
    width: 10,
    top: 40,
    left: -10,
    border: "0.25px solid black",
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
    position: 'relative',
    width: '50%'

  },
  eventDate: {
    fontWeight: "bold",
    textAlign: 'right',
    marginRight: '5px',
    display: 'flex',
  },
  eventTime: {
    color: "#777",
    fontFamily: "Quantico",
    marginLeft: "5px",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily: "Arial",
    display: 'inline-block',
    flexGrow: 1,
    whiteSpace: 'nowrap',
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
  },
 
  eventDescription: {
    lineHeight: "16px",
    height: "48px",
    fontSize: "14px",
    paddingRight: "10px",
    overflow: "hidden",
    fontFamily:"Lucida Fax",
    position: 'relative',
    display: 'inline-block',
    wordWrap: 'break-word',
    maxHeight: '3.4em', /* (Number of lines you want visible) * (line-height) */
    textAlign:'justify',
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 2,
    paddingTop: "20px",
    paddingRight: "15px",
    height: "auto",
    minWidth: "296px",
    maxWidth: "400px",
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
}));

const EventType13 = (props) => {
  const boxSize = props.boxSize ? props.boxSize : 'small'
  const boxWidth = (boxSize == 'small') ? 400 : 300

  const {
    start,
    title,
    description,
    imgURL,
    videoURL,
    audioURL,
    tags,
    starRating,
    color,
    tagColor,
    id,
    type2,
    eventType,
    groupImg,
    profileTagURL,
    country,
  } = props.item;

  
  console.log("EventVideoPlayer ::::::::::",`file:///${videoURL}` );
  
  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  const [itemStyle, setItemStyle] = React.useState(shapeStyle.eb1Style)

  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };

  return (
    <div>
      <div className={classes.root}>
        <div className={classes.eventRow}>
          <img className={classes.parentImg}
            style={{ borderColor: color, backgroundColor: '#fff', marginTop: (boxSize=='small'? 5:  56) }}
            alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
        <div className={classes.eventItem} onClick={handleSelect}>
       
          <div className={classes.eventDetails}>

            <div className={classes.itemEvent} 
              style={{
                width: (boxSize == 'small' ? 324 : 600),
                height: 'auto',
              }}>
              <div className={classes.itemHeader}>
                <div className={classes.eventTitle}>{title}</div>
                {
                  boxSize == 'large' ? 
                  <Rating
                    className={classes.eventRating}
                    value={starRating / 2}
                    max={10} 
                    precision={0.5}
                    size={'small'}
                    readOnly
                  /> : null
                }
                
              </div>
              <div className={classes.videoContainer}>
                <iframe
                  width="100%"
                  height={boxSize=='small'?'100%':'315'}
                  src={"https://audiomass.co/"}
                  frameborder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowfullscreen
                ></iframe>
                </div>
                <div className={classes.eventDate} style={{color: (boxSize == 'small' ? 'red' : '#777')}}>
                    <span style={{fontFamily:"Arial"}}>
                    {moment(start).format('DD MMM YYYY')}
                      </span>
                    <span>&nbsp;-&nbsp;</span>
                    <span className={classes.eventTime}>
                    {moment(start).format('HH:mm:ss')}
                    </span>

                    {
                      boxSize == 'small' ? 
                      <Rating
                        className={classes.eventRating}
                        value={starRating / 2}
                        max={5} 
                        precision={0.5}
                        size={'small'}
                        readOnly
                      /> : null
                    }
                  </div>
            </div>
          </div>
        

          <div
            className={classes.eventTags}
            style={{
              backgroundColor: (tagColor  ? tagColor  : color),
            }}
          >
            <div
              className={classes.tagText}
              style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
            >
              {tags.join(", ")}
              <CountryFlags
                  countryCode={country ? country : 'US'}
                  svg
                  style={{
                      width: 60,
                      height: 20,
                  }}
                  title={country}
                />
            </div>
          </div>
        </div>

        </div>
      </div>
      <Dialog
        open={select}
        onClose={handleUnSelect}
        aria-labelledby="item selected"
        aria-describedby="select an even to view it's details"
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflowY: "scroll",
          
        }}
        PaperProps={{
          style: {
            borderRadius: "10px",
            overflow:"visible",
            maxWidth: "initial"
          },
        }}
        fullWidth={true}
        maxWidth={"lg"}
      >
        <EventDetails onSave={props.onSaveEditModal} item={props.item} />
      </Dialog>
    </div>
  );
  
};
export default EventType13;
