import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import { bookmarkReadyToAdd } from "../../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "../EventDetails.js";
import CountryFlags from 'react-country-flag'
import moment from "moment"

//const EventItem=(item)=>({
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row",
    position: 'relative'
  },
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventImgContainer: {
    width: 363,
    height: 400,
    marginRight: 35,
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'flex-end'
  },
  eventImg: {
    objectFit: "cover",
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
  },
  parentImg: {
    height: 70,
    width: 70,
    borderRadius: 150,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "3px solid yellow",
    marginTop: 15,
    marginRight: 25
  },
  eventDetails: {
    filter: "drop-shadow(3px 5px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    height: 135,
    width: 400,
    padding: 5,
    borderRadius: 2,
    backgroundColor: "white",
    background: 'linear-gradient(to right, #BF953F, #FCF6BA, #B38728, #FBF5B7, #AA771C)',
    clipPath: "polygon(91% 0, 100% 26%, 100% 75%, 92% 100%, 0 100%, 0 0)"
  },
  
  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 0,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventPictureVLine: {
    position: "absolute",
    height: 50,
    zIndex: -1,
    display: 'block',
    backgroundColor: '#BF953F',
    bottom: 0,
    left: 25,
    width: 1, 
  },
  eventPictureLine: {
    position: "absolute",
    height: 1,
    display: 'block',
    backgroundColor: '#BF953F',
    top: 20,
    width: 100, 
    left: -50,
    zIndex: -1,
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventRating: {
    position: "absolute",
    left: "200px",
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
  },
  eventDate: {
    color: "red",
    fontWeight: "bold",
  },
  eventTime: {
    color: "black",
    fontFamily: "Quantico",
    marginLeft: "5px",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily:"Arial"
  },
  eventDescription: {
    lineHeight: "16px",
    height: "48px",
    width: '92%',
    fontSize: "14px",
    paddingRight: "2px",
    overflow: "hidden",
    fontFamily:"Lucida Fax",
    position: 'relative',
    display: 'inline-block',
    wordWrap: 'break-word',
    maxHeight: '3.4em', /* (Number of lines you want visible) * (line-height) */
    textAlign:'justify',
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 0,
    height: "auto",
    width: "296px",
    paddingTop: '10px',
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
  parentImgBottomTag: {
    bottom: 0,
    color: '#fff',
    left: 0,
    padding: '0px 8px',
    position: 'absolute',
    backgroundColor: '#000',
    border: '3px solid #BF953F',
    borderRadius: 4
  }
}));

const EventItem = (props) => {
  const bodyBgColor = props.bodyBgColor ? props.bodyBgColor : 'linear-gradient(to right, #BF953F, #FCF6BA, #B38728, #FBF5B7, #AA771C)'
  const {
    start,
    title,
    description,
    imgURL,
    videoURL,
    audioURL,
    tags,
    starRating,
    color,
    tagColor,
    id,
    type2,
    eventType,
    groupImg,
    profileTagURL,
    country,
  } = props.item;
console.log("bodyBgColor title", bodyBgColor, title, type2);
  
  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  
  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };

  return (
    <div>
      <div className={classes.root}>
      <div  className={classes.eventImgContainer}>
        <img className={classes.eventImg} alt="event picture" src={imgURL} />
      </div>
        <div className={classes.eventRow}>
          <div className={classes.parentImgBottomTag}>
            MUSIC
          </div>
          <img className={classes.parentImg}
            style={{ borderColor: color}}
            alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
            <div className={classes.eventPictureVLine}>
            </div>
            <div className={classes.eventPictureVLine} style={{left: 35}}>
            </div>
            <div className={classes.eventPictureVLine} style={{left: 45}}>
            </div>
        <div className={classes.eventItem} onClick={handleSelect}>

            <div className={classes.eventPictureLine}>
            </div>
            <div className={classes.eventPictureLine} style={{top: 50, left: -30}}>
            </div>
            <div className={classes.eventPictureLine} style={{top: 80}}>
            </div>
       
          <div className={classes.eventDetails}>

            <div className={classes.itemEvent} style={{background: bodyBgColor}}>
            
              <div className={classes.leftLine}>
              </div>
              <div className={classes.eventText}>
                <Rating
                  className={classes.eventRating}
                  value={starRating / 2}
                  precision={0.5}
                  size={'small'}
                  readOnly
                />
                <div className={classes.eventDate}>
                    <span style={{fontFamily:"Arial"}}>
                    {moment(start).format('DD MMM YYYY')}
                      </span>
                    <span className={classes.eventTime}>
                      {moment(start).format('HH:mm:ss')}
                    </span>
                  </div>
                <div className={classes.eventTitle}>{title}</div>
                <div className={classes.eventDescription} dangerouslySetInnerHTML={{__html: description}}></div>
              </div>
            </div>
          </div>

          <div
            className={classes.eventTags}
            style={{
              backgroundColor: (tagColor  ? tagColor  : color),
            }}
          >
            <div
              className={classes.tagText}
              style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
            >
              {tags.join(", ")}
            </div>
          </div>
        </div>

        </div>
      </div>
      <Dialog
        open={select}
        onClose={handleUnSelect}
        aria-labelledby="item selected"
        aria-describedby="select an even to view it's details"
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflowY: "scroll",
          
        }}
        PaperProps={{
          style: {
            borderRadius: "10px",
            overflow:"visible",
            maxWidth: "initial"
          },
        }}
        fullWidth={true}
        maxWidth={"lg"}
      >
        <EventDetails onSave={props.onSaveEditModal} item={props.item} />
      </Dialog>
    </div>
  );
  
};
export default EventItem;
