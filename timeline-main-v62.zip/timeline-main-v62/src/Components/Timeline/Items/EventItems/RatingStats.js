import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import { bookmarkReadyToAdd } from "../../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "../EventDetails.js";
import ProfileEvent from "../eventModals/profileModal";
import GraphModal from "../eventModals/graphModal";
import CountryFlags from 'react-country-flag'
import shapeStyle from "../shapeStyles"
import moment from "moment"
import StarIcon from '../../../../Assets/oneStar.svg'
import ThumbsUpIcon from '../../../../Assets/thumbsUp.svg'
import HeartIcon from '../../../../Assets/heart.svg'

//const EventType13=(item)=>({
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row",
    position: 'relative'
  },
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventImg: {
    width: 100,
    height: 120,
    marginRight: 27,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
  },
  parentImg: {
    width: 70,
    height: 70,
    backgroundColor: '#000',
    borderRadius: 150,
    marginTop: 55,
    right: 10,
    padding: 7,
    marginRight: 25
  },
  eventPictureLine: {
    position: "absolute",
    height: 0,
    display: 'block',
    backgroundColor: 'black',
    width: 51,
    zIndex: -1,
    top: 90,
    left: 45,
    border: "2px solid black",
  },
  eventDetails: {
    filter: "drop-shadow(5px 8px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    padding: 10,
    border: "1px solid black",
    borderRadius: 8,
    backgroundColor: "#ff0000",
    clipPath: "polygon(91% 0, 100% 26%, 100% 75%, 92% 100%, 0 100%, 0 0)",
    width: '400px',
    height: '120px',
  },
  itemHeader: {
    display: 'flex',
    flexDirection: 'row',
    paddingBottom: 10,
    justifyContent: 'space-between'
  },
  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 5,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
    position: 'relative',
    width: '50%'

  },
  eventDate: {
    fontWeight: "700",
    fontSize: '1.1em',
    marginRight: '5px',
    fontFamily: "Roboto",
    color: '#fff'
  },
  eventTime: {
    color: "#fff",
    fontSize: '0.9em',
    fontFamily: "Quantico",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily: "Arial",
    display: 'inline-block',
    flexGrow: 1,
    whiteSpace: 'nowrap',
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
  },
 
  eventDescription: {
    fontWeight: "700",
    padding: '5px 0px',
    maxWidth: 280,
    fontSize: '0.8rem',
    fontFamily: "Roboto",
    display: 'inline-block',
    whiteSpace: 'nowrap',
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
    color: '#fff'

  },
  ratingTitle: {
    fontFamily: 'Roboto',    
    overflow: 'hidden !important',
    fontWeight: '700',
    fontSize: '0.9em',
    textOverflow: 'ellipsis',
    width: 118,
    whiteSpace: 'nowrap'
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 2,
    paddingTop: "20px",
    paddingRight: "15px",
    height: "auto",
    minWidth: "296px",
    maxWidth: "400px",
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
  eventHeader: {
    backgroundColor: '#222',
    padding: 3,
    width: 310,
    textTransform: 'uppercase',
    fontFamily: 'Lucida Fax',
    fontSize: '1.4em',
    fontWeight: '700',
    color: '#fff'
  },
  eventHeaderIcon: {
    marginLeft: 5
  }
}));

const EventType20 = (props) => {
  const boxSize = props.boxSize ? props.boxSize : 'small'
  const boxWidth = (boxSize == 'small') ? 400 : 300
  const {
    start,
    title,
    description,
    imgURL,
    videoURL,
    audioURL,
    tags,
    starRating,
    color,
    tagColor,
    id,
    type2,
    eventType,
    groupImg,
    profileTagURL,
    country,
  } = props.item;

  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  const [itemStyle, setItemStyle] = React.useState(shapeStyle.eb1Style)

  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };

  return (
    <div>
      <div className={classes.root}>
        <div className={classes.eventRow}>
          <img width="80%" height="50%" className={classes.parentImg}
            alt="event picture" src={StarIcon} />
            <div className={classes.eventPictureLine}>
            </div>
        <div className={classes.eventItem} onClick={handleSelect}>
          <div className={classes.eventHeader}>
              Rating Stats &nbsp;
              <img width={25} height={25} className={classes.eventHeaderIcon} src={StarIcon}/>
              <img width={25} height={25} className={classes.eventHeaderIcon} src={ThumbsUpIcon}/>
              <img width={25} height={25} className={classes.eventHeaderIcon} src={HeartIcon}/>
              <img width={25} height={25} className={classes.eventHeaderIcon} src={ThumbsUpIcon} style={{transform: 'rotate(180deg)'}}/>
          </div>
          <div className={classes.eventDetails}>

            <div className={classes.itemEvent}>
              <div className={classes.itemHeader}>
                <div className={classes.eventDate}>
                    {moment(start).format('DD MMM YYYY')}  
                    <span className={classes.eventTime}>
                      &nbsp;
                      {moment(start).format('HH:mm:ss')}
                    </span>
                  </div>
                
              </div>
              <div className="ratingLCDContainer" style={{ marginBottom: 8, position: 'relative', height: 40, paddingLeft: 5}}>
                <img src={imgURL}
                    width={30}
                    height={30}
                    style={{
                        position: 'absolute',
                        left: 0,
                        top: 2,
                        border: '2px solid #efefef',
                        borderRadius: 4
                    }}/>
                <div style={{backgroundColor: '#222', borderRadius: 8, marginLeft: 10, marginRight: 10, paddingRight: 5, display: 'flex', justifyContent: 'space-between', alignItems:'center', height: 35}}>
                    <span className={classes.ratingTitle} style={{marginLeft: 20, color:'#fff'}}>{title} Im ready to expand and we are doing</span>
                    <Rating
                        className='LCDEventRating'
                        value={starRating * 2}
                        readOnly
                        max={10} 
                        size={"small"} 
                        readOnly
                    />
                </div>
                <div className={classes.eventDescription} dangerouslySetInnerHTML={{__html: description}}></div>
                    
                </div>
            </div>
          </div>
        

          <div
            className={classes.eventTags}
            style={{
              backgroundColor: (tagColor  ? tagColor  : color),
            }}
          >
            <div
              className={classes.tagText}
              style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
            >
              {tags.join(", ")}
            </div>
          </div>
        </div>

        </div>
      </div>
      <Dialog
        open={select}
        onClose={handleUnSelect}
        aria-labelledby="item selected"
        aria-describedby="select an even to view it's details"
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflowY: "scroll",
          
        }}
        PaperProps={{
          style: {
            borderRadius: "10px",
            overflow:"visible",
            maxWidth: "initial"
          },
        }}
        fullWidth={true}
        maxWidth={"lg"}
      >
        <EventDetails onSave={props.onSaveEditModal} item={props.item} />
      </Dialog>
    </div>
  );
  
};
export default EventType20;
