import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import { bookmarkReadyToAdd } from "../../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "../EventDetails.js";
import CountryFlags from 'react-country-flag'
import moment from "moment"

import "firebase/auth";
import "firebase/database";
import firebase from "firebase/app";

//const EventItem=(item)=>({
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row",
    position: 'relative'
  },
  eventImgContainer: {
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    width: 340,
    height: 400,
  },
  eventImg: {
    objectFit: "cover",
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
    width: '100%',
    height: '100%',
    marginRight: 58,
  },
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventItemLarge: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
    margin: 'auto',
    marginLeft: '-8px',
    marginTop: '87px'
  },
  
  parentImg: {
    height: 120,
    width: 120,
    borderRadius: 150,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "10px solid yellow",
    marginTop: 15,
    marginRight: 8
  },
  parentImgLarge: {
    height: 335,
    padding: 5,
    width: 335,
    borderRadius: 200,
    marginTop: 0,
    objectFit: "cover",
    backgroundColor: "transparent",
    border: "10px solid yellow",
  },
  eventDetails: {
    filter: "drop-shadow(3px 5px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    height: 135,
    width: 400,
    padding: 5,
    border: '1px solid #222',
    borderRadius: 2,
    backgroundColor: "white",
    background: '#fff',
    borderTopRightRadius: 100,
    borderBottomRightRadius: 100,
  },
  
  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 0,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventPictureVLine: {
    position: "absolute",
    height: 50,
    zIndex: -1,
    display: 'block',
    backgroundColor: '#BF953F',
    bottom: 0,
    left: 25,
    width: 1, 
  },
  eventPictureLine: {
    position: "absolute",
    height: 1,
    display: 'block',
    backgroundColor: '#000',
    top: 30,
    width: 100, 
    left: -50,
    zIndex: -1,
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventRating: {
    position: "absolute",
    left: "200px",
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
  },
  eventDate: {
    color: "red",
    fontWeight: "bold",
  },
  eventTime: {
    color: "black",
    fontFamily: "Quantico",
    marginLeft: "5px",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily:"Arial",
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
  },
  eventDescription: {
    lineHeight: "16px",
    height: "70px",
    width: '92%',
    fontSize: "14px",
    paddingRight: "2px",
    overflow: "hidden",
    fontFamily:"Lucida Fax",
    position: 'relative',
    display: 'inline-block',
    wordWrap: 'break-word',
    maxHeight: '60px', /* (Number of lines you want visible) * (line-height) */
    textAlign:'justify',
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 0,
    height: "auto",
    width: "296px",
    paddingTop: '10px',
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
  parentImgBottomTag: {
    bottom: 0,
    color: '#fff',
    left: 0,
    padding: '0px 8px',
    position: 'absolute',
    backgroundColor: '#000',
    border: '3px solid #BF953F',
    borderRadius: 4
  }
}));

const EventItem = (props) => {
  const bodyBgColor = props.bodyBgColor ? props.bodyBgColor : 'linear-gradient(to right, #BF953F, #FCF6BA, #B38728, #FBF5B7, #AA771C)'
  const parentImageSize = props.parentImageSize ? props.parentImageSize : 'large'
  
  const {
    otherImages,
    videoURL,
    audioURL,
    id,
    type2,
    eventType,
    groupImg,
    country,
    group,
    color,
    sex
  } = props.item;

  const [start, setStart] = React.useState(props.item.start);
  const [title, setTitle] = React.useState(props.item.title);
  const [description, setDescription] = React.useState(props.item.description);
  const [imgURL, setImgURL] = React.useState(props.item.imgURL);
  const [tags, setTags] = React.useState(props.item.tags);
  const [starRating, setStarRating] = React.useState(props.item.starRating);
  const [tagColor, setTagColor] = React.useState(props.item.tagColor);
  const [profileTagURL, setProfileTagURL] = React.useState(props.item.profileTagURL);

  var genderIcon = (sex && (sex.toLowerCase() == 'female' || sex.toLowerCase() == 'f')) 
                    ? require('../../../../Assets/femaleIcon.svg').default
                    : require('../../../../Assets/maleIcon.svg').default

  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  
  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };


  async function fetchGroupEventData (){
    const currentUser = firebase.auth().currentUser;
    const eventRef = firebase.database().ref("Timelines/" + currentUser.uid + "/" + group + "/" + id);
    const eventData = await eventRef.once('value')

    console.log("Timelines/" + currentUser.uid + "/" + group + "/" + id);
    let evData = eventData.val()
    setStart(evData['start'])
    setTitle(evData["title"])
    setDescription(evData['description'])
    setImgURL(evData["ebPicURL"])
    setTags(evData['tags'])
    setStarRating(evData['starRating'])
    setTagColor(evData["tagColor"])
    setProfileTagURL(evData["profileTagURL"])  
  }
  
  React.useEffect(function () {
    fetchGroupEventData()
  }, [id])
  return (
    <div>
      <div className={classes.root}>
        {parentImageSize == 'small' ? 
        <div className={classes.eventImgContainer}>
          <img className={classes.eventImg} alt="event picture" src={imgURL} /> </div>
          : null}
        <div className={classes.eventRow}>
         
          <img className={((parentImageSize == 'small') ? classes.parentImg: classes.parentImgLarge)}
            style={{ borderColor: (tagColor ? tagColor : color), }}
            alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
            
        <div className={(parentImageSize == 'small') ? classes.eventItem : classes.eventItemLarge} onClick={handleSelect}>
        <div className={classes.eventPictureLine}/>
        <div className={classes.eventPictureLine} style={{top: 120}}/>
             
          <div className={classes.eventDetails}>

            <div className={classes.itemEvent} style={{borderColor: (tagColor ? tagColor : color)}}>
              <div className={classes.eventText}>
                <div className={classes.eventDate}>
                    <span style={{fontFamily:"Arial"}}>
                    {moment(start).format('DD MMM YYYY')}
                      </span>
                    <span className={classes.eventTime}>
                      {moment(start).format('HH:mm:ss')}
                    </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <img src={genderIcon} width={25} />
                  </div>
              
                <div className={classes.eventTitle}>{title}</div>
                <div className={classes.eventDescription} dangerouslySetInnerHTML={{__html: description}}></div>
              </div>
            </div>
          </div>

          <div
            className={classes.eventTags}
            style={{
              backgroundColor: (tagColor  ? tagColor  : color),
            }}
          >
            <div
              className={classes.tagText}
              style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
            >
              {tags.join(", ")}
            </div>
          </div>
        </div>

        </div>
      </div>
      <Dialog
        open={select}
        onClose={handleUnSelect}
        aria-labelledby="item selected"
        aria-describedby="select an even to view it's details"
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflowY: "scroll",
          
        }}
        PaperProps={{
          style: {
            borderRadius: "10px",
            overflow:"visible",
            maxWidth: "initial"
          },
        }}
        fullWidth={true}
        maxWidth={"lg"}
      >
        <EventDetails onSave={fetchGroupEventData} item={{
          ...props.item,
          start,
          title,
          description,
          imgURL,
          tags,
          starRating,
          tagColor,
          profileTagURL,
        }} />
      </Dialog>
    </div>
  );
  
};
export default EventItem;
