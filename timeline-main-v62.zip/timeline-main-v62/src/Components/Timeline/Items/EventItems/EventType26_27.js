import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import { bookmarkReadyToAdd } from "../../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "../EventDetails.js";
import CountryFlags from 'react-country-flag'
import moment from "moment"

//const EventItem=(item)=>({
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row",
    position: 'relative'
  },
  eventImgContainer: {
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    width: 385,
    height: 400,
    marginRight: 15,

  },
  eventImg: {
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
    width: '100%',
    height: '100%',
  },
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventItemLarge: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
    margin: 'auto',
    marginLeft: '-8px',
    marginTop: '87px'
  },
  
  parentImg: {
    height: 120,
    width: 120,
    borderRadius: 150,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "10px solid yellow",
    marginTop: 15,
    marginRight: 25,
    zIndex: 1
  },
  parentImgLarge: {
    height: 335,
    padding: 5,
    width: 335,
    borderRadius: 200,
    marginTop: 0,
    objectFit: "cover",
    backgroundColor: "transparent",
    border: "10px solid yellow",
  },
  eventPictureHLines: {
    position: "absolute",
    height: 120,
    zIndex: 1,
    display: 'block',
    backgroundColor: '#000',
    top: 10,
    left: -5,
    width: 1, 
  },
  eventPictureVLargeHeightLine: {
    position: "absolute",
    height: 40,
    display: 'block',
    backgroundColor: 'red',
    top: 50,
    width: 100, 
    left: -50,
    zIndex: -1,
  },
  eventPictureLine: {
    position: "absolute",
    height: 1,
    display: 'block',
    backgroundColor: '#000',
    top: 35,
    width: 100, 
    left: -50,
    zIndex: -1,
  },
  triAngleBoxLine: {
    position: "absolute",
    height: 3,
    display: 'block',
    backgroundColor: '#000',
    top: 41,
    width: 100, 
    zIndex: 1,
    right: -95,
    transform: 'rotate(29deg)'
  },
  triAngleBoxLine2: {
    position: "absolute",
    height: 3,
    display: 'block',
    backgroundColor: '#000',
    bottom: 41,
    width: 100, 
    zIndex: 1,
    right: -95,
    transform: 'rotate(-29deg)'
  },
  eventDetails: {
    filter: "drop-shadow(3px 5px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    height: 135,
    width: 400,
    padding: 5,
    borderRadius: 2,
    backgroundColor: "white",
    background: '#fff',
    borderTopRightRadius: 100,
    borderBottomRightRadius: 100,
  },

  itemEvent27: {
    position: "relative",
    height: 135,
    width: 400,
    padding: 5,
    borderRadius: 2,
    background: '#fff',
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
  },
  
  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 0,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventRating: {
    position: "absolute",
    marginLeft: "10px",
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
  },
  eventDate: {
    color: "red",
    fontWeight: "bold",
  },
  eventTime: {
    color: "black",
    fontFamily: "Quantico",
    marginLeft: "5px",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily:"Arial"
  },
  eventDescription: {
    lineHeight: "16px",
    height: "70px",
    width: '92%',
    fontSize: "14px",
    paddingRight: "2px",
    overflow: "hidden",
    fontFamily:"Lucida Fax",
    position: 'relative',
    display: 'inline-block',
    wordWrap: 'break-word',
    maxHeight: '60px', /* (Number of lines you want visible) * (line-height) */
    textAlign:'justify',
    overflow: 'hidden !important',
    textOverflow: 'ellipsis',
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 0,
    height: "auto",
    width: "90%",
    paddingTop: '10px',
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
  parentImgBottomTag: {
    bottom: 0,
    color: '#fff',
    left: 0,
    padding: '0px 8px',
    position: 'absolute',
    backgroundColor: '#000',
    border: '3px solid #BF953F',
    borderRadius: 4
  }
}));

const EventItem = (props) => {
  const bodyBgColor = props.bodyBgColor ? props.bodyBgColor : 'linear-gradient(to right, #BF953F, #FCF6BA, #B38728, #FBF5B7, #AA771C)'
  const parentImageSize = props.parentImageSize ? props.parentImageSize : 'large'
  const {
    start,
    title,
    description,
    imgURL,
    videoURL,
    audioURL,
    tags,
    starRating,
    color,
    tagColor,
    id,
    type2,
    eventType,
    groupImg,
    profileTagURL,
    country,
    sex,
    flag
  } = props.item;

  var genderIcon = (sex && (sex.toLowerCase() == 'female' || sex.toLowerCase() == 'f')) 
                    ? require('../../../../Assets/femaleIcon.svg').default
                    : require('../../../../Assets/maleIcon.svg').default

  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  
  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };

  return (
    <div>
      <div className={classes.root}>
        { type2 == 'eb27' 
        ? <div className={classes.eventImgContainer}>
            <img className={classes.eventImg} alt="event picture" src={imgURL} /> 
          </div>
        : null}
        
        <div className={classes.eventRow}>

         {
           type2 == 'eb27'  
            ? <img className={classes.parentImg}
                  style={{ borderColor: (tagColor ? tagColor : color),  marginRight: 10}}
                  alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
            : <img className={classes.parentImg}
                  style={{ borderColor: (tagColor ? tagColor : color)}}
                  alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
         }
        <div className={classes.eventItem} onClick={handleSelect}>
        <div className={classes.eventPictureLine}/>
        <div className={classes.eventPictureLine} style={{top: 115}}/>
             
          <div className={classes.eventDetails}>
            {
              type2 == 'eb27' 
              ? [
                  <div className={classes.eventPictureVLargeHeightLine} style={{backgroundColor: (tagColor ? tagColor : color)}}/>,
                  <div className={classes.triAngleBoxLine} />,
                  <div className={classes.triAngleBoxLine2} />
                ]
              : [
                <div className={classes.eventPictureHLines}/>,
                <div className={classes.eventPictureHLines} style={{left: -15, height: 100, top: 25}}/>,
                <div className={classes.eventPictureHLines} style={{left: -25, height: 80, top: 35}}/>
              ] 
            }

            <div className={(type2 == 'eb27' ? classes.itemEvent27 : classes.itemEvent)}>
              <div className={classes.eventText}>
                <div className={classes.eventDate}>

                   
                  
                  <span style={{fontFamily:"Arial"}}>
                      {moment(start).format('DD MMM YYYY')}
                      </span>
                    <span className={classes.eventTime}>
                      {moment(start).format('HH:mm:ss')}
                    </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                  
                  <Rating
                    className={classes.eventRating}
                    value={starRating / 2}
                    precision={0.5}
                    size={'small'}
                    readOnly
                  />
                </div>
              
                <div className={classes.eventTitle}>{title}</div>
                <div className={classes.eventDescription} dangerouslySetInnerHTML={{__html: description}}></div>
              </div>
            </div>
          </div>

          <div
            className={classes.eventTags}
            style={{
              backgroundColor: (tagColor  ? tagColor  : color),
            }}
          >
            <div
              className={classes.tagText}
              style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
            >
              {tags.join(", ")}

              {
                type2 == 'eb27'
                ? <CountryFlags
                    countryCode={flag ? flag : 'US'}
                    svg
                    style={{
                        width: 60,
                        height: 20,
                    }}
                    title={flag}
                  />
                : null
              }
            </div>
          </div>
        </div>

        </div>
      </div>
      <Dialog
        open={select}
        onClose={handleUnSelect}
        aria-labelledby="item selected"
        aria-describedby="select an even to view it's details"
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflowY: "scroll",
          
        }}
        PaperProps={{
          style: {
            borderRadius: "10px",
            overflow:"visible",
            maxWidth: "initial"
          },
        }}
        fullWidth={true}
        maxWidth={"lg"}
      >
        <EventDetails onSave={props.onSaveEditModal} item={props.item} />
      </Dialog>
    </div>
  );
  
};
export default EventItem;
