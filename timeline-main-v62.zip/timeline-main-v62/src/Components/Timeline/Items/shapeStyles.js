export default  {
    eb1Style: {
        eventBoxShape: {
            clipPath: "polygon(91% 0, 100% 26%, 100% 75%, 92% 100%, 0 100%, 0 0)"
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventPictureLine: {
            display: 'block',
            zIndex: 1
        },
        eventImg: {
            maxWidth: 300
        } 
        
    },

    eb2Style: {
        eventBoxShape: {
            clipPath: "polygon(91% 0, 100% 26%, 100% 75%, 92% 100%, 0 100%, 0 0)"
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventPictureLine: {
            display: 'block',
        },
        eventImgContainer: {
            marginRight: 0,

        },
    },

    eb3Style: {
        eventBoxShape: {
            clipPath: "polygon(0 0, 100% 0, 100% 70%, 97% 80%, 5% 80%, 0 100%)",
        },
        parentImage: {

        },
        eventTags: {
            width: '310px',
            paddingTop: '120px',
            left: 2

        },
        eventImgContainer: {
            marginRight: 0,
            width: 320
        }
    },
    
    eb4Style: {
        eventBoxShape: {
            borderTopRightRadius: 20,
            borderBottomRightRadius: 20
        },
        eventImgContainer: {
            marginRight: 12,
            width: 310
        }
    },

    eb5Style: {
        eventBoxShape: {
            borderRadius: 20
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventTags: {
            left: 3,
            borderTopLeftRadius: 50
        },
        leftLine: {
            marginTop: 12 
        },
        eventPictureLine: {
            display: 'block',
        },
        eventImgContainer: {
            marginRight: 15,
            width: 295
        },
        eventImg: {
            maxWidth: '100%'
        } 
    },
    
    eb6Style: {
        eventBoxShape: {
            borderRadius: 50,
            width: 330,
            paddingLeft: 10
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventPictureLine: {
            display: 'block',
        },
        eventTags: {
            left: 2,
            borderTopLeftRadius: 50,
            borderTopRightRadius: 50
        },
        leftLine: {
            marginTop: 25,
            height: 80 
        },
        eventRating: {
            left: 200
        },
        eventImgContainer: {
            marginRight: 40,
        },
        eventImg: {
            maxWidth: 250
        } 
    },
    eb7Style: {
        eventBoxShape: {
            borderRadius: 50,
            width: 330,
            paddingLeft: 10
        },
        eventPictureLine: {
            display: 'block',
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventTags: {
            left: 2,
            borderTopLeftRadius: 50,
            borderTopRightRadius: 50
        },
        leftLine: {
            marginTop: 25,
            height: 80 
        },
        eventRating: {
            left: 200
        },
        eventImgContainer: {
            marginRight: 40,
            width: 250
        },
        eventImg: {
            maxWidth: 250
        }  
    },
    eb8Style: {
        eventBoxShape: {
            borderRadius: 50,
            width: 330,
            paddingLeft: 10
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventTags: {
            left: 2,
            borderTopLeftRadius: 50,
            borderTopRightRadius: 50
        },
        leftLine: {
            marginTop: 25,
            height: 80 
        },
        eventRating: {
            left: 200
        },
        eventPictureLine: {
            display: 'block',
        },
        eventImgContainer: {
            marginRight: 40,
            width: 250
        },
        eventImg: {
            maxWidth: 250
        } 
    },
    eb9Style: {
        eventBoxShape: {
            borderRadius: 50,
            width: 330,
            paddingLeft: 10
        },
        parentImage: {
            borderRadius: 150, 
            marginRight: 20,
            marginTop: 25,
            marginRight: 5
        },
        eventTags: {
            left: 2,
            borderTopLeftRadius: 50,
            borderTopRightRadius: 50
        },
        leftLine: {
            marginTop: 25,
            height: 80 
        },
        eventRating: {
            left: 200
        },
        eventPictureLine: {
            display: 'block',
        },
        eventImgContainer: {
            marginRight: 40,
            width: 250
        },
        eventImg: {
            maxWidth: 250
        } 
    },
    eb10Style: {
        eventRating: {
            left: 190
        },
        eventBoxShape: {
            clipPath: "polygon(92% 0, 100% 10%, 100% 100%, 0 100%, 0 0)",
            height: 350,
            width: 300
        },
        parentImage: {},
        eventImg: {
            marginRight: 0,
        },
        eventDescription: {
            height: 'auto',
            display: 'flex',
            justifyContent: 'space-between',
            maxHeight: '237px',
        },
        eventDescriptionText: {
            marginRight: 8,
            textAlign: 'left',
        },
        eventTags: {
            width: '295px',
            top: 220
        },
        eventSeparatorLine1: {
            display: 'block'
        },
        eventSeparatorLine2: {
            display: 'block'
        },
        eventImg: {
            maxWidth: 120,
            height: 150
        }
    },
    eb11Style: {
        eventRating: {
            left: 190
        },
        eventBoxShape: {
            clipPath: "polygon(0 0, 100% 0%, 100% 100%, 0% 100%)",
            height: 350,
            width: 300
        },
        parentImage: {},
        eventImg: {
            marginRight: 0,
        },
        eventDescription: {
            height: 'auto',
            display: 'flex',
            justifyContent: 'space-between',
            maxHeight: '237px',
        },
        eventDescriptionText: {
            marginRight: 8,
            textAlign: 'left',
        },
        eventTags: {
            width: '295px',
            top: 220
        },
        eventTitle: {
            textAlign: 'center',
            fontFamily: 'Chomsky'
        },
        eventSeparatorLine1: {
            display: 'block',
            width: '80%',
            marginLeft: '10%' 
        },
        eventSeparatorLine2: {
            display: 'block',
            width: '80%',
            marginLeft: '10%', 
        },
        eventImg: {
            maxWidth: 120,
            height: 150
        }
    },
    eb12Style: {
        eventRating: {
            left: 190
        },
        eventBoxShape: {
            borderRadius: 15,
            height: 350,
            width: 300,
            overflow: 'hidden'
        },
        parentImage: {
            marginTop: 10
        },
        eventTitle: {
            textAlign: 'center',
            marginBottom: 8
        },
        eventImg: {
            marginRight: 0,
        },
        eventDescription: {
            height: 'auto',
            display: 'flex',
            justifyContent: 'space-between',
            maxHeight: '237px',
        },
        eventDescriptionText: {
            marginRight: 8,
            textAlign: 'left',
        },
        eventTags: {
            width: '295px',
            top: 220
        },
        eventSeparatorLine1: {
            display: 'block'
        },
        eventSeparatorLine2: {
            display: 'none'
        },
        eventImg: {
            maxWidth: 120,
            height: 150
        }
    }
}