import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Rating } from "@material-ui/lab";
import { useDispatch } from "react-redux";
import moment from 'moment'
import { bookmarkReadyToAdd } from "../../../Redux/Actions/BookmarksActions.js";
import Modal from "@material-ui/core/Modal";
import Dialog from "@material-ui/core/Dialog";
import EventDetails from "./EventDetails.js";
import ProfileEvent from "./eventModals/profileModal";
import GraphModal from "./eventModals/graphModal";
import CountryFlags from 'react-country-flag'
import shapeStyle from "./shapeStyles"

import "firebase/auth";
import "firebase/database";
import firebase from "firebase/app";

import EventType13 from './EventItems/EventType13'
import EventVideoPlayer from './EventItems/EventVideoPlayer'
import EventAudioPlayer from './EventItems/EventAudioPlayer'
import EventType19 from './EventItems/EventType19'
import EventType20 from './EventItems/RatingStats'
import EventType22 from './EventItems/EventType22'
import EventType23 from './EventItems/EventType23'
import EventType24 from './EventItems/EventType24'
import EventType26_27 from './EventItems/EventType26_27'
import EventTypePicture from './EventItems/PictureEventType'

//const EventItem=(item)=>({
const generateContrastColor = (color = "#fff") => {
  const ref = "0123456789abcdef";
  return (
    "#" +
    color
      .slice(1)
      .split("")
      .map((e) => ref[15 - ref.indexOf(e)])
      .join("")
  );
};
const useStyles = makeStyles((theme) => ({
  descLine: {
    border: '1px solid #222'
  },
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
  },
  eventRow: {
    display: "flex",
    flexDirection: "row"
  },
  eventImgContainer: {
    width: 296,
    maxHeight: 400,
    marginRight: 25,
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'flex-end'
  },
  eventItem: {
    position: "relative",
    height: "auto",
    "&:hover": {
      cursor: "pointer",
    },
  },
  eventImg: {
    height: 'auto',
    width: 'auto',
    objectFit: "cover",
    backgroundColor: "blue",
    border: "1px solid black",
    marginBottom: 2,
  },
  parentImg: {
    width: 70,
    height: 70,
    objectFit: "cover",
    backgroundColor: "blue",
    border: "3px solid yellow",
    borderTopLeftRadius: 15,
    borderBottomLeftRadius: 15,
    marginTop: 2,
    zIndex: 1,
  },
  eventDetails: {
    filter: "drop-shadow(5px 8px 2px black)",
    height: "auto",
  },

  itemEvent: {
    position: "relative",
    height: 135,
    width: 324,
    padding: 5,
    border: "1px solid black",
    borderRadius: 2,
    backgroundColor: "white",
  },

  leftLine: {
    position: "absolute",
    height: "80%",
    width: 0,
    marginLeft: 5,
    borderRight: "0.25px solid black",
    marginTop: 5,
    marginBottom: 160,
  },
  eventPictureLine: {
    position: "absolute",
    height: 0,
    display: 'none',
    backgroundColor: 'black',
    width: 10,
    top: 40,
    left: -10,
    border: "0.25px solid black",
    zIndex: -1
  },
  eventSeparatorLine: {
    height: 0,
    backgroundColor: 'black',
    display: 'none',
    width: '100%',
    borderTop: "0.25px solid #555",
    marginTop: 5,
    marginBottom: 10
  },
  eventRating: {
    position: "absolute",
    left: "200px",
  },
  eventText: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
    height: "auto",
  },
  eventDate: {
    color: "red",
    fontWeight: "bold",
  },
  eventTime: {
    color: "black",
    fontFamily: "Quantico",
    marginLeft: "5px",
  },
  eventTitle: {
    fontWeight: "bold",
    fontSize: 18,
    fontFamily:"Arial",
    textOverflow: 'ellipsis', 
    whiteSpace: 'nowrap',
    overflow: 'hidden' 
  },
  eventDescription: {
    lineHeight: "16px",
    height: "48px",
    fontSize: "14px",
    paddingRight: "10px",
    overflow: "hidden",
    fontFamily:"Lucida Fax",
    position: 'relative',
    display: 'inline-block',
    wordWrap: 'break-word',
    maxHeight: '3.4em', /* (Number of lines you want visible) * (line-height) */
    textAlign:'justify',
  },
  eventTags: {
    position: "absolute",
    backgroundColor: "yellow",
    zIndex: -10,
    left: 2,
    paddingTop: "145px",
    height: "auto",
    width: "296px",
    top: "0px",
    borderRadius: "0 0 30px 0",
    display: "flex",
    alignItems: "flex-end",
    alignContent: "flex-end",
    fontSize: "13px",
    fontWeight: "bold",
    lineHeight: "15px",
    fontFamily:"Big Noodle Titling"
  },
  tagText: {
    color: "#fff",
    fontSize: "1.2em",
    fontWeight: '700',
    paddingBottom: "15px",
    paddingLeft: "10px",
    paddingRight: 2,
    fontFamily: "Quantico",
    display: 'flex',
    alignItems: 'end',
    justifyContent: 'space-between'
  },
}));

const EventItem = (props) => {

  const {
    otherImages,
    videoURL,
    audioURL,
    id,
    type2,
    eventType,
    groupImg,
    country,
    group,
    color,
    flag
  } = props.item;

  const [start, setStart] = React.useState(props.item.start);
  const [title, setTitle] = React.useState(props.item.title);
  const [description, setDescription] = React.useState(props.item.description);
  const [imgURL, setImgURL] = React.useState(props.item.imgURL);
  const [tags, setTags] = React.useState(props.item.tags);
  const [starRating, setStarRating] = React.useState(props.item.starRating);
  const [tagColor, setTagColor] = React.useState(props.item.tagColor);
  const [profileTagURL, setProfileTagURL] = React.useState(props.item.profileTagURL);

  const [eventData, setEventData] = React.useState(props.item)

  
  const classes = useStyles();
  const dispatch = useDispatch();
  const [select, setSelect] = React.useState(false);
  const [itemStyle, setItemStyle] = React.useState(shapeStyle.eb1Style)

  React.useEffect(function () {
    switch (type2) {
      case 'eb1':
        setItemStyle(shapeStyle.eb1Style)
        break;
        case 'eb2':
          setItemStyle(shapeStyle.eb5Style)
          break;
        case 'eb3':
          setItemStyle(shapeStyle.eb3Style)
          break;
        case 'eb4':
          setItemStyle(shapeStyle.eb4Style)
          break;
        case 'eb5':
          setItemStyle(shapeStyle.eb5Style)
          break;
        case 'eb6':
          setItemStyle(shapeStyle.eb6Style)
          break;
        case 'eb7':
          setItemStyle(shapeStyle.eb7Style)
          break;
        case 'eb8':
          setItemStyle(shapeStyle.eb8Style)
          break;
        case 'eb9':
          setItemStyle(shapeStyle.eb9Style)
          break;
        case 'eb10':
          setItemStyle(shapeStyle.eb10Style)
          break;
          case 'eb11':
            setItemStyle(shapeStyle.eb11Style)
            break;
          case 'eb12':
          setItemStyle(shapeStyle.eb12Style)
          break;
      default:
        setItemStyle(shapeStyle.eb4Style)

        break;
    }
  }, [props])

  const eventDetailModal = () => {

    switch (type2) {
      case "eb1":
        return <ProfileEvent onSave={fetchGroupEventData} item={eventData} />
      case "eb2":
        return <EventDetails onSave={fetchGroupEventData} item={eventData} />
      case "eb3":
        return <GraphModal onSave={fetchGroupEventData} item={eventData} />
      case "eb4":
        return <EventDetails onSave={fetchGroupEventData} item={eventData} />
      case "eb5":
        return <GraphModal onSave={fetchGroupEventData} item={eventData} />
        case "eb6":
      return <EventDetails onSave={fetchGroupEventData} item={eventData} />
      case "eb7":
        return <EventDetails onSave={fetchGroupEventData} item={eventData} />
      case "eb8":
        return <GraphModal onSave={fetchGroupEventData} item={eventData} />
        case "eb9":
        return <EventDetails onSave={fetchGroupEventData} item={eventData} />
      case "eb10":
        return <GraphModal onSave={fetchGroupEventData} item={eventData} />
      case "eb11":
        return <EventDetails onSave={fetchGroupEventData} item={eventData} />
      case "eb12":
        return <GraphModal onSave={fetchGroupEventData} item={eventData} />
    
      default:
        return <EventDetails onSave={fetchGroupEventData} item={eventData} />
    }
  }

  const handleSelect = () => {
    dispatch(bookmarkReadyToAdd({ id, title }));
    setSelect(true);
  };
  const handleUnSelect = () => {
    dispatch(bookmarkReadyToAdd(null));
    setSelect(false);
  };

  async function fetchGroupEventData (){
    const currentUser = firebase.auth().currentUser;
    const eventRef = firebase.database().ref("Timelines/" + currentUser.uid + "/" + group + "/" + id);
    const eventData = await eventRef.once('value')
    let evData = eventData.val()


    setStart(evData['start_date'])
    setTitle(evData["title"])
    setDescription(evData['description'])
    setImgURL(evData["ebPicURL"])
    setTags(evData['tags'])
    setStarRating(evData['starRating'])
    setTagColor(evData["tagColor"])
    setProfileTagURL(evData["profileTagURL"])

    setEventData({
      ...props.item,
      start: evData['start_date'],
      title: evData["title"],
      description: evData["description"],
      imgURL: evData["ebPicURL"],
      tags: evData["tags"],
      starRating: evData["starRating"],
      tagColor: evData["tagColor"],
      profileTagURL: evData["profileTagURL"],
      notes: evData["notes"]
    })
  
  }
  
  React.useEffect(function () {
    fetchGroupEventData()
  }, [id])

  if(type2 == 'eb10' || type2 == 'eb11' || type2 == 'eb12') {

    return (
      <div>
        <div className={classes.root}>
          
          <div className={classes.eventRow}>
          
            <img className={classes.parentImg}
              style={{ borderColor: color, ...itemStyle.parentImage }}
              alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
          <div className={classes.eventItem} style={{width: 320}} onClick={handleSelect}>
         
            <div className={classes.eventDetails}>
      
              <div className={classes.itemEvent} style={{ ...itemStyle.eventBoxShape }}>
                
                  <div className={classes.eventText}>
                    <Rating
                      className={classes.eventRating}
                      style={{...itemStyle.eventRating}}
                      value={starRating / 2}
                      precision={0.5}
                      size={'small'}
                      readOnly
                    />
                    <div className={classes.eventDate}>
                      <span style={{fontFamily:"Arial"}}>
                        {moment(start).format('DD MMM YYYY')}
                        </span>
                      <span className={classes.eventTime}>
                        {moment(start).format('HH:mm:ss')}
                      </span>
                    </div>
                    <div className={classes.eventSeparatorLine} style={{...itemStyle.eventSeparatorLine1}}></div>
                    <div className={classes.eventTitle} style={{...itemStyle.eventTitle}}>{title}</div>
                    <div className={classes.eventSeparatorLine} style={{...itemStyle.eventSeparatorLine2}}></div>
                    <div className={classes.eventDescription} style={{...itemStyle.eventDescription}}>
                      <div style={{...itemStyle.eventDescriptionText}} dangerouslySetInnerHTML={{__html: description}}></div>
                      <img className={classes.eventImg} style={{...itemStyle.eventImg}} alt="event picture" src={imgURL} />
                    </div>
                  </div>
                </div>
            </div>
  
            <div
              className={classes.eventTags}
              style={{
                backgroundColor: (tagColor ? tagColor : color),
                ...itemStyle.eventTags,
              }}
            >
              <div
                className={classes.tagText}
              >
                <span style={{ color: generateContrastColor((tagColor? tagColor : color)) }}>{tags?.join(", ")}&nbsp;</span> 
                <CountryFlags
                  countryCode={flag ? flag : 'US'}
                  svg
                  style={{
                      width: 60,
                      height: 20,
                  }}
                  title={country}
                />
              </div>
            </div>
          </div>
  
          </div>
        </div>
        <Dialog
          open={select}
          onClose={handleUnSelect}
          aria-labelledby="item selected"
          aria-describedby="select an even to view it's details"
          style={{
            width: "100vw",
            height: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            overflowY: "scroll",
            
          }}
          PaperProps={{
            style: {
              borderRadius: "10px",
              overflow:"visible",
              maxWidth: "initial"
            },
          }}
          fullWidth={true}
          maxWidth={"lg"}
        >
          <EventDetails onSave={fetchGroupEventData} item={eventData} />
        </Dialog>
      </div>
    );
  } 
  else if (type2 == 'eb13') {
    return <EventType13 boxSize="large" onSaveEditModal={fetchGroupEventData}  item={eventData}/>
  }
  else if (type2 == 'eb14') {
    return <EventType13 boxSize="small" onSaveEditModal={fetchGroupEventData}  item={eventData}/>
  }
  else if (type2 == 'eb15') {
    return <EventVideoPlayer boxSize="large" onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb16') {
    return <EventVideoPlayer boxSize="small" onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb17') {
    return <EventAudioPlayer boxSize="small" onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb18') {
    return <EventAudioPlayer boxSize="small" onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb19') {
    return <EventType19 onSaveEditModal={fetchGroupEventData}  item={eventData}/>
  }
  else if (type2 == 'eb20') {
    return <EventType20  onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb21') {
    return <EventType19 bodyBgColor="#fff" onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb22') {
    return <EventType22 bodyBgColor="#fff" onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb23') {
    return <EventType23 onSaveEditModal={fetchGroupEventData}  item={eventData}/>
  }
  else if (type2 == 'eb24') {
    return <EventType24 parentImageSize={'large'} onSaveEditModal={fetchGroupEventData}  item={eventData}/>
  }
  else if (type2 == 'eb25') {
    return <EventType24 parentImageSize={'small'} onSaveEditModal={fetchGroupEventData}  item={eventData}/>
  }
  else if (type2 == 'eb26') {
    return <EventType26_27 onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else if (type2 == 'eb27') {
    return <EventType26_27 onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else  if(type2  ==  'eb28')  {
    return  <EventTypePicture onSaveEditModal={fetchGroupEventData} item={eventData}/>
  }
  else {
    return (
      <div>
        <div className={classes.root}>
        <div  className={classes.eventImgContainer} style={{...itemStyle.eventImgContainer}}>
          <img className={classes.eventImg} style={{...itemStyle.eventImg}} alt="event picture" src={imgURL} />
        </div>
          <div className={classes.eventRow}>
          
            <img className={classes.parentImg}
              style={{ borderColor: color, ...itemStyle.parentImage }}
              alt="event picture" src={profileTagURL === undefined ? groupImg : profileTagURL} />
          <div className={classes.eventItem} onClick={handleSelect}>
         
            <div className={classes.eventDetails}>
            <div className={classes.eventPictureLine} style={{...itemStyle.eventPictureLine}}>
              </div>
              <div className={classes.eventPictureLine} style={{...itemStyle.eventPictureLine, top: 60, width: 6, left: -6}}>
              </div>
              <div className={classes.eventPictureLine} style={{...itemStyle.eventPictureLine, top: 80, width: 12, left: -12}}>
              </div>
              <div className={classes.itemEvent} style={{ ...itemStyle.eventBoxShape }}>
              
                <div className={classes.leftLine} style={{...itemStyle.leftLine}}>
                </div>
                <div className={classes.eventText}>
                  <Rating
                    className={classes.eventRating}
                    style={{...itemStyle.eventRating}}
                    value={starRating / 2}
                    precision={0.5}
                    size={'small'}
                    readOnly
                  />
                  <div className={classes.eventDate}>
                    <span style={{fontFamily:"Arial"}}>
                      {moment(start).format('DD MMM YYYY')}
                      </span>
                    <span className={classes.eventTime}>
                      {moment(start).format('HH:mm:ss')}
                    </span>
                  </div>
                  <div className={classes.eventTitle}>{title}</div>
                  <div className={classes.eventDescription} dangerouslySetInnerHTML={{__html: description}}>
                  </div>
                  
                </div>
              </div>
            </div>
  
            <div
              className={classes.eventTags}
              style={{
                backgroundColor: (tagColor  ? tagColor  : color),
                ...itemStyle.eventTags
              }}
            >
              <div
                className={classes.tagText}
                style={{ color: generateContrastColor((tagColor  ? tagColor  : color)) }}
              >
                {tags?.join(", ")}
              </div>
            </div>
          </div>
  
          </div>
        </div>
        <Dialog
          open={select}
          onClose={handleUnSelect}
          aria-labelledby="item selected"
          aria-describedby="select an even to view it's details"
          style={{
            width: "100vw",
            height: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            overflowY: "scroll",
            
          }}
          PaperProps={{
            style: {
              borderRadius: "10px",
              overflow:"visible",
              maxWidth: "initial"
            },
          }}
          fullWidth={true}
          maxWidth={"lg"}
        >
          {
            eventDetailModal()
          }
        </Dialog>
      </div>
    );
  }
  
};
export default EventItem;
