import React from "react";

const BookMarkTitleContext = React.createContext("Bookmark Title");

export default BookMarkTitleContext;
