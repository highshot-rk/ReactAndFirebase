import React from "react";
import Draggable from 'react-draggable';
import "./LCDGraph.css";
import {Line} from "react-chartjs-2"
import CountryFlags from 'react-country-flag'
const LCDGraph = (props) => {
  const groupData = props.group
  const expandCanvasItemHandler = (event) => {
    if(props.expandCanvasItem) props.expandCanvasItem(props.group);
  };

  const getProfileName = (firstName, motherName, formerName) => {
    let name = ''
    if(firstName) name = firstName
    if(motherName) name = name + ' ' + motherName
    if(formerName) name = name + ' ' + formerName
    return name
  }
  const [graphData, setGraphData] = React.useState([])
  const rawChartData = {
    stockFullName: "SW Limited.",
    stockShortName: "ASX:SFW",
    price: {
      current: 2.32,
      open: 2.23,
      low: 2.215,
      high: 2.325,
      cap: 93765011,
      ratio: 20.1,
      dividend: 1.67,
    },
    chartData: {
      labels: [
        "10:00",
        "",
        "",
        "",
        "12:00",
        "",
        "",
        "",
        "2:00",
        "",
        "",
        "",
        "4:00",
      ],
      data: [
        2.23,
        2.215,
        2.22,
        2.25,
        2.245,
        2.27,
        2.28,
        2.29,
        2.3,
        2.29,
        2.325,
        2.325,
        2.32,
      ],
    },
  };

  const buildData = ({chartData}) => ({
    labels: chartData.labels,
    datasets: [
        {
            label: "",
            backgroundColor: "rgba(255, 255, 255, 0.1)",
            borderColor: "#222",
            pointBackgroundColor: "#222",
            data: chartData.data,
        },
    ],
});

const options = {
  legend: {
      display: false,
  },
  scales: {
      yAxes: [
          {
              ticks: {
                  fontColor: "rgba(255, 255, 255, 1)",
              },
              gridLines: {
                  display: false,
              },
          },
      ],
      xAxes: [
          {
              ticks: {
                  fontColor: "rgba(255, 255, 255, 1)",
              },
              gridLines: {
                  color: "rgba(255, 255, 255, .2)",
                  borderDash: [5, 5],
                  zeroLineColor: "rgba(255, 255, 255, .2)",
                  zeroLineBorderDash: [5, 5],
              },
          },
      ],
  },
  layout: {
      padding: {
          right: 10,
      },
  },
};

  const initChartData = () => {
    const data = buildData(rawChartData);
    setGraphData(data)
  }

  React.useEffect(function(){
    initChartData()
  }, [])

  return (
    <Draggable
      handle=".canvasItem"
      position={null}
      grid={[50, 50]}
      scale={1}>
      <div className="canvasItem profile">
        <div
          className="canvasItemTitle"
        >
          <h4 className="normalText tx-bold" style={{fontSize: '1.2em'}}>
            Graph Namable
            
          </h4>
        </div>
        <div className="canvasItemDetail">
          <div className="topEdge">
            <span className="arrow" onClick={expandCanvasItemHandler}>
              <span className="arrowBorder">
                <span className="arrowInner"></span>
              </span>
              <span className="arrowConnector"></span>
            </span>
          </div>
          <div className="detail">
            <div id="graphCanvas" style={{width: '100%', border: '1.5px solid #ccc'}}>
              <Line data={graphData} options={options} />
            </div>
          </div>
          <div className="bottomEdge"></div>
        </div>
      </div>
    </Draggable>
  );
};

export default LCDGraph;
