import React from "react";
import Draggable from 'react-draggable';
import "./LCDProfile.css";
import CountryFlags from 'react-country-flag'
const LCDProfile = (props) => {
  const profileColor = props.group.color;
  const groupData = props.group
  const expandCanvasItemHandler = (event) => {
    props.expandCanvasItem(props.group);
  };

  const getProfileName = (firstName, motherName, formerName) => {
    let name = ''
    if(firstName) name = firstName
    if(motherName) name = name + ' ' + motherName
    if(formerName) name = name + ' ' + formerName
    return name
  }

  return (
      <div className="canvasItem profile">
        <div
          className="canvasItemTitle"
        >
          <h4 className="normalText tx-bold" style={{fontSize: '1.2em'}}>
            Profile
            <img
              alt="female"
              src={require("../../../Assets/femaleIcon.svg").default}
            />
          </h4>
        </div>
        <div className="canvasItemDetail">
          <div className="topEdge">
            <span className="arrow" onClick={expandCanvasItemHandler}>
              <span className="arrowBorder">
                <span className="arrowInner"></span>
              </span>
              <span className="arrowConnector"></span>
            </span>
          </div>
          <div className="detail" style={{
              width: '400px',
              overflowY: 'scroll',
              overflowX: 'hidden',
            }}> 
            <div style={{
              width: '100%',
              
            }}>
              <div>
                <span className="normalText" style={{fontSize: '1rem', marginRight: 20}}>
                  Name:
                </span>
                <span className="tx-bold normalText" style={{fontSize: '1rem'}}>
                  {getProfileName(groupData.firstName,  groupData.motherName ,groupData.formerName)}
                </span>
                <hr className="hr"/>
              </div>

              <div className="d-flex flex-row">
                <div style={{borderRight: '2px solid #80b7ff', width: '144px', marginRight: 5}}>
                  <div>
                    <span className="normalText">
                      Brithdate: &nbsp; <span className="tx-bold">{groupData.age}</span>
                    </span>
                  </div>
                  <div className="spaceTop">
                    <span className="normalText">
                      Location: &nbsp; <CountryFlags
                          countryCode={groupData.flag ? groupData.flag : 'US'}
                          svg
                          style={{
                              width: 39,
                              height: 15,
                              margin: 0,
                              padding: 0
                          }}
                          title={groupData.flag}
                      />
                    </span>
                  </div>
                </div>
                <div>
                  <div>
                    <p className="normalText tx-bold text-right">{groupData.birthDate}</p>
                  </div>
                  <div className="spaceTop">
                    <p className="normalText tx-bold text-right">{groupData.locations}</p>
                  </div>
              </div>
              </div>
              <div style={{marginTop: 8}}>
                <div style={{display: 'flex', flexDirection: 'row', alignItems: 'flex-end', marginBottom: 5}}>
                  <p className="normalText" style={{fontSize: '1rem'}}>
                    BIOGRAPHY 
                  </p>
                  <hr className="hr" style={{width: '100%', marginLeft: 5}}/>
                </div>
                <p className="normalText" style={{textAlign: 'justify'}}>
                  {groupData.biography}What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has?
                </p>
              </div>

            </div>
            <div 
              style={{ 
                marginLeft: '10px', 
                marginTop: 23,
                width: 110, 
                height: 105,
                backgroundImage: `url(${groupData.imageURL})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
                borderRadius: '5px' 
              }}>
              
            </div>
          </div>
          <div className="bottomEdge"></div>
        </div>
      </div>
  );
};

export default LCDProfile;
