import React from 'react';

import './LCDDialogContent.css';
import ProfileModal from './Modals/ProfileModal'
const DialogContent = (props) => {
    return (
        <ProfileModal item={props.data}/>
    );
};

export default DialogContent;