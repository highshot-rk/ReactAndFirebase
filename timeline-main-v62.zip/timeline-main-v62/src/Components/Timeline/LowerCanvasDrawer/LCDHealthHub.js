import React from "react";
import Draggable from 'react-draggable';
import "./LCDHealthHub.css";
import {Line} from "react-chartjs-2"
import CountryFlags from 'react-country-flag'
import HealthHubPulse from '../../../Assets/healthhub_puls.jpg'
import HealthHub from '../../../Assets/healthhub.jpg'

const LCDHealthHub = (props) => {
  const groupData = props.group
  const headerColor = props.headerColor ? props.headerColor :  'rgb(43 42 56)'
  const headerTextColor = props.textColor ? props.textColor :  '#fff'
  const bodyBgColor = props.bgColor ? props.bgColor :  '#fff'
  const cardSize = (props.size == 'large') ? 'large' :  'small'

  const expandCanvasItemHandler = (event) => {
    if(props.expandCanvasItem) props.expandCanvasItem(props.group);
  };

  const getProfileName = (firstName, motherName, formerName) => {
    let name = ''
    if(firstName) name = firstName
    if(motherName) name = name + ' ' + motherName
    if(formerName) name = name + ' ' + formerName
    return name
  }


  function  randomImage() {
    let number = Math.floor(Math.random() * 6) + 1
    if(number % 2 == 0) 
      return HealthHubPulse
    else 
      return HealthHub
  }
  
  React.useEffect(function(){
  }, [])

  return (
    <Draggable
      handle=".canvasItem"
      position={null}
      grid={[50, 50]}
      scale={1}>
      <div className="canvasItem profile">
        <div
          className="canvasItemTitle"
          style={{ backgroundColor: headerColor}}
        >
          <h4 className="normalText tx-bold" style={{fontSize: '1.2em', color: headerTextColor}}>
            Health Hub &nbsp;
            <img
              alt="female"
              src={require("../../../Assets/femaleIcon.svg").default}
            />
          </h4>
        </div>
        <div className="canvasItemDetail">
          <div className="topEdge" style={{borderBottom: ('29px solid '+bodyBgColor)}}>
            <span className="arrow" onClick={expandCanvasItemHandler}>
              <span className="arrowBorder">
                <span className="arrowInner"></span>
              </span>
              <span className="arrowConnector"></span>
            </span>
          </div>
          <div className="detail"
            style={{
              height: (cardSize =='large' ? 300 : 180),
              backgroundColor: bodyBgColor,
            }}>
            <div id="graphCanvas" style={{width: '100%', border: '1.5px solid #ccc'}}>
              <img width="100%" height="100%" src={randomImage()}/>
            </div>
          </div>
          <div className="bottomEdge" style={{borderTop: ('29px solid '+bodyBgColor)}}></div>
        </div>
      </div>
    </Draggable>
  );
};

export default LCDHealthHub;
