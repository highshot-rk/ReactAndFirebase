import React from 'react';

import './LCDEvent.css';
import Draggable from 'react-draggable';
import {Line} from "react-chartjs-2"
import CountryFlags from 'react-country-flag'

const LCDEvent = (props) => {
    const {
        start,
        title,
        description,
        imgURL,
        videoURL,
        audioURL,
        tags,
        starRating,
        color,
        tagColor,
        id,
        type2,
        eventType,
        groupImg,
        profileTagURL,
        country,
    } = props.event
    const expandCanvasItemHandler = (event) => {
        if(props.expandCanvasItem) props.expandCanvasItem(props.group);
    };

  const getProfileName = (firstName, motherName, formerName) => {
    let name = ''
    if(firstName) name = firstName
    if(motherName) name = name + ' ' + motherName
    if(formerName) name = name + ' ' + formerName
    return name
  }
 

  React.useEffect(function(){

  }, [])

  return (
    <Draggable
      handle=".canvasItem"
      position={null}
      grid={[50, 50]}
      scale={1}>
      <div className="canvasItem profile">
        <div
          className="canvasItemTitle d-flex flex-row"
          style={{justifyContent: 'space-between', alignItems: 'center'}}
        >
          <h4 className="normalText tx-bold" style={{fontSize: '1.2em'}}>
            Event &nbsp; <img  src={require("../../../Assets/tlEventLogo.svg").default}/>
          </h4>

          <h4 className="normalText tx-bold" style={{fontSize: '1em'}}>
            {title} 
          </h4>
        </div>
        <div className="canvasItemDetail">
          <div className="topEdge">
            <span className="arrow" onClick={expandCanvasItemHandler}>
              <span className="arrowBorder">
                <span className="arrowInner"></span>
              </span>
              <span className="arrowConnector"></span>
            </span>
          </div>
          <div className="detail">
            <img width={'100%'} src={require("../../../Assets/pinned_event_defualt.png").default} />
          </div>
          <div className="bottomEdge"></div>
        </div>
      </div>
    </Draggable>
  );
}

export default LCDEvent;



