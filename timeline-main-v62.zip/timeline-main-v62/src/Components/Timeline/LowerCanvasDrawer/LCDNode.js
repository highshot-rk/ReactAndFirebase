import React from 'react';

import './LCDNode.css';

const LCDNode = (props) => {
    return (
        <div></div>
    );
};

export default LCDNode;