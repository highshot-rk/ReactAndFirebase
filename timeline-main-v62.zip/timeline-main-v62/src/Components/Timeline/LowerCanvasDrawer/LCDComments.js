import React from 'react';
import CountryFlags from 'react-country-flag'
import './LCDComments.css';
import Rating from "@material-ui/lab/Rating";
import Draggable from 'react-draggable';

const LCDComments = (props) => {
    console.log("LCDProfile ::", props.group);
    const profileColor = props.group?.color;
    const groupData = props.group ? props.group : {}
    const expandCanvasItemHandler = (event) => {
      if(props.expandCanvasItem)  props.expandCanvasItem(props.group);
    };
  
    const getProfileName = (firstName, motherName, formerName) => {
      let name = ''
      if(firstName) name = firstName
      if(motherName) name = name + ' ' + motherName
      if(formerName) name = name + ' ' + formerName
      return name
    }
  
    return (

    <div className="canvasItem comments" style={{width: 450}}>
        <div
          className="canvasItemTitle d-flex"
          style={{backgroundColor: '#efefef', border: '1px solid #222', justifyContent: 'center', position: 'relative'}}
        >
          <h4 className="tx-bold normalText" style={{fontSize: '1.2em', textAlign: 'center', color: '#222'}}>
          <img
              alt="male"
              width={18}
              style={{marginRight: 1}}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              width={18}
              style={{marginRight: 1}}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              width={18}
              style={{marginRight: 1}}
              style={{marginRight: 1}}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              width={18}
              style={{marginRight: 1}}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
            alt="male"
            width={18}
            style={{marginRight: 1}}
            src={require("../../../Assets/maleIcon.svg").default}
          />
            &nbsp;
            Comments
            &nbsp;
            <img
              alt="male"
              style={{marginRight: 1}}
              width={18}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              style={{marginRight: 1}}
              width={18}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              width={18}
              style={{marginRight: 1}}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              style={{marginRight: 1}}
              width={18}
              src={require("../../../Assets/maleIcon.svg").default}
            />
            <img
              alt="male"
              width={18}
              style={{marginRight: 1}}
              src={require("../../../Assets/maleIcon.svg").default}
            />

          </h4>
          <div style={{position: 'absolute', right: 8}}>
            <img
              alt="male"
              width={25}
              src={require("../../../Assets/lcdComments.svg").default}
            />
          </div>
        </div>
        <div className="canvasItemDetail">
          <div className="topEdge">
            <span className="arrow" onClick={expandCanvasItemHandler}>
              <span className="arrowBorder">
                <span className="arrowInner"></span>
              </span>
              <span className="arrowConnector"></span>
            </span>
          </div>
          <div className="detail">
           <div style={{
              width: 400,
              overflowY: 'scroll',
              overflowX: 'hidden',
             }}>
             <div className="commentContainer" style={{paddingBottom: '25px'}}>
                <img width={60} style={{border: '2px solid green', borderRadius: 2, marginRight: 8}} height={80} src={require("../../../Assets/abc.jpg").default}/>
                <div>
                  <h3 className="tx-bold normalText activityTitle">Recently Activity</h3>
                  <div className="commentActivity">
                    <img src={require("../../../Assets/heart.svg").default}/>
                    <span className="activityText">&nbsp; Mia Sara likes your Timeline</span>
                  </div>
                  <div className="commentActivity">
                    <img src={require("../../../Assets/thumbsUp.svg").default}/>
                    <span className="normalText activityText">&nbsp; Mia Sara likes your photo <span className="normalText activityTime">Fri at 10.30 am</span></span>
                  </div>
                  <div className="commentActivity">
                    <img src={require("../../../Assets/heart.svg").default}/>
                    <span className="normalText activityText">&nbsp; Mia Sara likes your Timeline</span>
                    <Rating
                        className='LCDEventRating'
                        value={(10 / 2)}
                        readOnly
                        max={5} 
                        size={"small"} 
                        readOnly
                    />
                  </div>
                </div>
             </div>
             <div className="commentContainer">
                <img width={60} style={{border: '2px solid green', borderRadius: 2, marginRight: 8}} height={80} src={require("../../../Assets/abc.jpg").default}/>
                <div>
                  <h3 className="tx-bold normalText activityTitle">Timeline user 3001</h3>
                  <div className="commentActivity">
                    <img src={require("../../../Assets/heart.svg").default}/>
                    <span className="normalText activityText">&nbsp; Hi really like your work on the Freedom Timeline!</span>
                    <Rating
                        className='LCDEventRating'
                        value={(10 / 2)}
                        readOnly
                        max={5} 
                        size={"small"} 
                        readOnly
                    />
                  </div>
                  <div className="commentActivity">
                    <span className="normalText activityText activityTime">Fri at 10.30 am</span>
                  </div>
                </div>
             </div>
           </div>
          </div>
          <div className="bottomEdge"></div>
        </div>
      </div>
    );
  };

export default LCDComments;