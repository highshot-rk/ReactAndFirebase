import React from 'react';
import './LCDRatings.css';
import Rating from "@material-ui/lab/Rating";
import CountryFlags from 'react-country-flag'
import StarIcon from "../../../Assets/oneStar.svg"
import Draggable from 'react-draggable';
import Star from '@material-ui/icons/Star';
const LCDRatings = (props) => {
    const profileColor = props.events?.color;
    const groupsData = props.groupData ? props.groupData : []
    const headerColor = props.headerColor ? props.headerColor :  'rgb(43 42 56)'
    const headerTextColor = props.textColor ? props.textColor :  '#fff'
    const bodyBgColor = props.bgColor ? props.bgColor :  'red'
    const cardSize = (props.size == 'large') ? 'large' :  'small'

    const [eventData, setEventData] = React.useState([])
    var ratingIcon = StarIcon
    const expandCanvasItemHandler = (event) => {
      if(props.expandCanvasItem) props.expandCanvasItem(props.events);
    };
  
    React.useEffect(function() {
      let tempArr = []
        if(props.events) {
          if(Array.isArray(groupsData)){
            groupsData.map((group, index) => {
              tempArr = [...tempArr, ...props.events[group.timeline_id]]
            })
          }
        } 
        setEventData(tempArr)
    }, [props])
  
    return (
      <Draggable
        handle=".canvasItem"
        position={null}
        scale={1}
        grid={[50, 50]}
        >
      
    
      <div className="canvasItem comments" style={{width: (cardSize =='large' ? 500 : 400)}}>
        <div
          className="canvasItemTitle"
          style={{ backgroundColor: headerColor}}
        >
          <h4 className="tx-bold normalText" style={{fontSize: '1.2em', fontWeight: '700', color: headerTextColor}}>
            Rating Meter &nbsp;
            <img
              alt="female"
              width={25}
              height={25}
              src={StarIcon}
            />
          </h4>
        </div>
        <div className="canvasItemDetail">
          <div className="topEdge" style={{borderBottom: ('29px solid '+bodyBgColor)}}>
            <span className="arrow" onClick={expandCanvasItemHandler}>
              <span className="arrowBorder">
                <span className="arrowInner"></span>
              </span>
              <span className="arrowConnector"></span>
            </span>
          </div>
          <div className="detail" style={{
              width: '100%',
              height: (cardSize =='large' ? 300 : 180),
              padding: '2px',
              paddingLeft: '6px',
              paddingRight: '6px',
              backgroundColor: bodyBgColor
            }}>
            <div style={{
                width: '100%',
                overflowY: 'scroll',
                overflowX: 'hidden',
            }}>
                {
                    eventData.map((event)=> {
                        return <div className="ratingLCDContainer" style={{ marginBottom: 8, position: 'relative', height: 40, paddingLeft: 5}}>
                                    <img src={event.ebPicURL}
                                        width={30}
                                        height={30}
                                        style={{
                                            position: 'absolute',
                                            left: 0,
                                            top: 2,
                                            border: '2px solid #efefef',
                                            borderRadius: 4
                                        }}/>
                                    <div style={{backgroundColor: '#222', borderRadius: 8, marginLeft: 10, marginRight: 10, paddingRight: 5, display: 'flex', justifyContent: 'space-between', alignItems:'center', height: 35}}>
                                        <span className="ratingLCDEventTitle normalText" style={{marginLeft: 20, color:'#fff'}}>{event.title}</span>
                                        <Rating
                                            className='LCDEventRating'
                                            value={(event.starRating ? event.starRating : 0) * 2}
                                            readOnly
                                            max={10} 
                                            size={"small"} 
                                            readOnly
                                        />
                                    </div>
                                    <div style={{margin: '0 auto', height: 4, marginTop: 5, width: '95%', backgroundColor: '#fff'}}/>
                                    
                                </div>
                      })
                }
            </div>
              
          </div>
          <div className="bottomEdge" style={{borderTop: ('29px solid '+bodyBgColor)}}></div>
        </div>
      </div>
      </Draggable>
    );
};

export default LCDRatings;
