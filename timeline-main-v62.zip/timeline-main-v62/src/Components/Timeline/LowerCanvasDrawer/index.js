
import React, { useState, useEffect } from "react";

import LCDProfile from "../LowerCanvasDrawer/LCDProfile";
import LCDRatings from "../LowerCanvasDrawer/LCDRatings";
import LCDEvent from "../LowerCanvasDrawer/LCDEvent";
import LCDGraph from "../LowerCanvasDrawer/LCDGraph";
import LCDGPSTracking from "../LowerCanvasDrawer/LCDGPSTracking";
import LCDHealthHub from "../LowerCanvasDrawer/LCDHealthHub";
import LCDNode from "../LowerCanvasDrawer/LCDNode";
import LCDComments from "../LowerCanvasDrawer/LCDComments";
import LCDHouseSecurity from "../LowerCanvasDrawer/LCDHouseSecurity";
export default  function TimelineLCD (props) {
    const expandCanvasItem = props.expandCanvasItem
    const groupsData =  props.groupsData ? props.groupsData : []
    const itemsData =  props.itemsData ? props.itemsData : []
    const LCDType = props.LCDType 
    
    useEffect((params) => {
        
    }, [])

    switch (LCDType) {
      case 'TimelineLCD':
        return <TimelineDefault/>
      case 'ProfileLCD':
        return <TimelineProfile/>
        case 'RatingsLCD':
        return <TimelineRatingsLCD/>
      case 'GPSTrackingLCD':
        return <TimelineGPSTrackingLCD/>
      case 'HouseSecurityLCD':
        return <TimelineHouseSecurityLCD/>
      case 'HealthHubLCD':
        return <TimelineHealthHubLCD/>
      case 'TimelineLCD':
        return <TimelineDefault/>
      case 'TimelineLCD':
        return <TimelineDefault/>
      case 'TimelineLCD':
        return <TimelineDefault/>
      default:
        return <TimelineDefault/>
    }

    function TimelineDefault() {
      return (
        <div id="canvasDrawer" className="canvasItemContainer">
              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              { groupsData.map((group, index) => {
                  return itemsData[group.timeline_id].map((event)=>{
                    if(event.eventPinned) {
                      return <LCDEvent event={event} expandCanvasItem={expandCanvasItem} />
                    } 
                  })
              })}

              <LCDRatings groupData={groupsData} events={itemsData}/>

              <LCDNode />

              <LCDComments />
              
              <LCDGraph events={itemsData}/>
        </div>
      )
    }

    function TimelineProfile() {
      return (
        <div id="canvasDrawer" className="canvasItemContainer">
            {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              <LCDRatings groupData={groupsData} events={itemsData}/>
              <LCDComments />

              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
        </div>
      )
    }

    function TimelineRatingsLCD() {
      return (
        <div id="canvasDrawer" className="canvasItemContainer">
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="star"/> 
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="heart"/>
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="thumb"/>
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="smile" bgColor="#ddd" headerColor="#555"/>
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="star"  bgColor="#ddd" headerColor="#555"/>
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="star"  bgColor="#ddd" headerColor="#555"/>

              <LCDRatings groupData={groupsData} events={itemsData} shapeType="star"  bgColor="rgb(51 71 169)" size="large"/>
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="star"  bgColor="rgb(51 71 169)" size="large"/>
              <LCDRatings groupData={groupsData} events={itemsData} shapeType="star"  bgColor="rgb(51 71 169)" size="large"/>
        </div>
      )
    }

    function TimelineGPSTrackingLCD() {
      return (
        <div id="canvasDrawer" className="canvasItemContainer">
              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              <LCDGPSTracking groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDGPSTracking groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              
              <LCDComments />

              <LCDGPSTracking groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDGPSTracking groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDGPSTracking groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
        </div>
      )
    }
    function TimelineHealthHubLCD() {
      return (
        <div id="canvasDrawer" className="canvasItemContainer">
              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              <LCDHealthHub groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              
              <LCDComments />

              <LCDHealthHub groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDHealthHub groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDHealthHub groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
        </div>
      )
    }

    function TimelineHouseSecurityLCD() {
      return (
        <div id="canvasDrawer" className="canvasItemContainer">
              {groupsData.map((group, index) => {
                let groupAndProfileData = {...itemsData[group.timeline_id][0], ...group}
                return <LCDProfile group={groupAndProfileData} expandCanvasItem={expandCanvasItem} />
              })}
              <LCDHouseSecurity groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              
              <LCDComments />

              <LCDHouseSecurity groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDHouseSecurity groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
              <LCDHouseSecurity groupData={groupsData} events={itemsData}  textColor="#222" headerColor="rgb(255 227 32)"/>
        </div>
      )
    }

}

